
import { api } from './api';
import { BrandMemory, ContentPlanItem } from "../types";

/**
 * PRD 3.1: The Intelligence Layer (Memory/RAG)
 * Now delegates to the Node.js backend to handle Pinecone communication.
 */
export const syncMemoryToPinecone = async (brandId: string, memory: BrandMemory) => {
  return api.post('/api/vector/store', { brandId, memory });
};

/**
 * PRD 7 & 7.1: Compliance Shield (Proxy & Jitter)
 * Backend handles the actual social API communication.
 */
export const publishWithCompliance = async (item: ContentPlanItem) => {
  return api.post('/api/publish', { item });
};

/**
 * PRD 4.1.B: Integrated Analytics Engine
 */
export const fetchLiveMetrics = async (postId: string): Promise<{ reach: number; engagement: number; roi: string } | null> => {
  return api.get(`/api/analytics/metrics/${postId}`);
};

/**
 * PRD 4.3: AI Avatar Processing
 */
export const runWav2Lip = async (videoUrl: string, audioUrl: string): Promise<string> => {
  const result = await api.post<{ output_video_url: string }>('/api/video/wav2lip', { videoUrl, audioUrl });
  return result.output_video_url;
};
