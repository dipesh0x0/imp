
/**
 * Centralized API Client
 * Mimics Axios behavior using fetch for clean backend communication.
 */

const BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || 'https://api.contentpilot.ai';

const getHeaders = () => {
  const token = localStorage.getItem('content_pilot_token');
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

export const api = {
  get: async <T>(endpoint: string): Promise<T> => {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: 'GET',
      headers: getHeaders(),
    });
    if (!response.ok) throw new Error(`API GET Error: ${response.statusText}`);
    return response.json();
  },

  post: async <T>(endpoint: string, body?: any): Promise<T> => {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!response.ok) throw new Error(`API POST Error: ${response.statusText}`);
    return response.json();
  },

  put: async <T>(endpoint: string, body?: any): Promise<T> => {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!response.ok) throw new Error(`API PUT Error: ${response.statusText}`);
    return response.json();
  },

  delete: async <T>(endpoint: string): Promise<T> => {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: 'DELETE',
      headers: getHeaders(),
    });
    if (!response.ok) throw new Error(`API DELETE Error: ${response.statusText}`);
    return response.json();
  }
};
