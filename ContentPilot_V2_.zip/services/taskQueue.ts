
import { ContentPlanItem } from "../types";
import { publishWithCompliance } from "./externalServices";

/**
 * PRD 4.3: Automated Scheduling Engine
 * Simulated BullMQ runner using LocalStorage persistence and intervals.
 */
export class BackgroundTaskRunner {
  private static instance: BackgroundTaskRunner;
  private queue: ContentPlanItem[] = [];

  private constructor() {
    this.loadQueue();
    setInterval(() => this.processQueue(), 60000); // Check every minute
  }

  public static getInstance(): BackgroundTaskRunner {
    if (!this.instance) this.instance = new BackgroundTaskRunner();
    return this.instance;
  }

  private loadQueue() {
    const saved = localStorage.getItem('pilot_task_queue');
    if (saved) this.queue = JSON.parse(saved);
  }

  private saveQueue() {
    localStorage.setItem('pilot_task_queue', JSON.stringify(this.queue));
  }

  public scheduleTask(item: ContentPlanItem) {
    this.queue.push(item);
    this.saveQueue();
    console.log(`PRD 4.3: Task scheduled for ${item.title} at node ${item.proxyNode}`);
  }

  private async processQueue() {
    const now = Date.now();
    const tasksToRun = this.queue.filter(t => t.scheduledAt && t.scheduledAt <= now);
    
    for (const task of tasksToRun) {
      try {
        console.log(`Running background task: ${task.title}`);
        await publishWithCompliance(task);
        this.queue = this.queue.filter(t => t.day !== task.day);
        this.saveQueue();
      } catch (e) {
        console.error("Task execution failed", e);
      }
    }
  }
}
