import { api } from './api';
import { BrandInfo, ContentPlanItem, Trend, BrandStrategy, BrandPersona } from '../types';

/**
 * Content Generation & Strategy
 * Orchestrates the creation of the 7-day OS plan.
 */
export const generatePlan = (brand: BrandInfo): Promise<ContentPlanItem[]> => 
  api.post('/api/generate/plan', brand);

export const generateImage = (prompt: string, aspectRatio: string = "1:1"): Promise<{ url: string }> => 
  api.post('/api/generate/image', { prompt, aspectRatio });

/**
 * Self-Hosted Video Engine (PRD 4.0 Finalized)
 * Routes directly to /api/generate/video backend proxy.
 * No local @google/genai SDK calls permitted here.
 */
export const generateVideo = (
  prompt: string, 
  quality: 'draft' | 'production' = 'draft', 
  aspectRatio: string = "9:16"
): Promise<{ url: string, engine: string }> => 
  api.post('/api/generate/video', { prompt, quality, aspectRatio });

export const generateVoiceover = (text: string, voiceName: string): Promise<{ data: string }> => 
  api.post('/api/generate/voiceover', { text, voiceName });

export const generatePersona = (brand: BrandInfo): Promise<BrandPersona> => 
  api.post('/api/generate/persona', brand);

export const generateAvatarVideo = (persona: BrandPersona, prompt: string): Promise<{ url: string }> => 
  api.post('/api/generate/avatar-video', { persona, prompt });

/**
 * Analysis & Feedback
 */
export const predictPerformance = (item: ContentPlanItem, brand: BrandInfo, trends: Trend[]): Promise<number> => 
  api.post('/api/analyze/predict-performance', { item, brand, trends });

export const runHookForensics = (item: ContentPlanItem): Promise<any> => 
  api.post('/api/analyze/hook-forensics', { item });

export const evaluateVisualCohesion = (plan: ContentPlanItem[], brand: BrandInfo): Promise<any> => 
  api.post('/api/analyze/visual-cohesion', { plan, brand });

export const checkCompetitiveCollision = (item: ContentPlanItem, brand: BrandInfo): Promise<any> => 
  api.post('/api/analyze/competitive-collision', { item, brand });

/**
 * Research & Monitoring
 */
export const scanTrends = (industry: string): Promise<Trend[]> => 
  api.post('/api/research/trends', { industry });

export const researchCompetitors = (brand: BrandInfo): Promise<BrandStrategy> => 
  api.post('/api/research/competitors', brand);

export const interceptTrendJack = (brand: BrandInfo): Promise<any> => 
  api.post('/api/research/trend-jack', brand);

/**
 * Editing & Modification
 */
export const editImage = (base64Data: string, mimeType: string, prompt: string): Promise<{ url: string }> => 
  api.post('/api/edit/image', { base64Data, mimeType, prompt });

/**
 * PRD 4.1: Video Inpainting (SAM 2 Powered)
 * Communicates with the temporal tracking backend.
 */
export const editVideo = (videoUrl: string, maskCoordinates: any, prompt: string): Promise<{ url: string }> => 
  api.post('/api/edit/video', { videoUrl, maskCoordinates, prompt });

export const geoAdaptContent = (item: ContentPlanItem, location: string, brand: BrandInfo): Promise<any> => 
  api.post('/api/edit/geo-adapt', { item, location, brand });

export const analyzeAsset = (base64Data: string, mimeType: string): Promise<string[]> => 
  api.post('/api/analyze/asset', { base64Data, mimeType });

/**
 * Utilities (Aesthetic Branding)
 */
export const applyBrandSignature = (canvas: HTMLCanvasElement, brandName: string) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const padding = 40;
  ctx.font = 'bold 24px "Plus Jakarta Sans"';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 10;
  const text = `@${brandName.toLowerCase().replace(/\s/g, '')}`;
  const metrics = ctx.measureText(text);
  ctx.fillText(text, canvas.width - metrics.width - padding, canvas.height - padding);
};

export const runPostMortem = (item: ContentPlanItem, success: boolean): Promise<string> => 
  api.post('/api/analyze/post-mortem', { item, success });

export const autoTuneMemoryFromMetrics = (item: ContentPlanItem, brand: BrandInfo): Promise<any> => 
  api.post('/api/analyze/auto-tune', { item, brand });
