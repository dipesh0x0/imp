import { GoogleGenAI, Type, Modality } from "@google/genai";
import { BrandInfo, ContentPlanItem, ContentType, Platform, Trend, BrandStrategy, GroundingSource, BrandPersona, Asset, BrandMemory } from "../types";

export const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found.");
  return new GoogleGenAI({ apiKey });
};

/**
 * Auto-Tuning Feedback Loop
 * Analyzes real metrics to determine if a prompt was successful DNA.
 */
export const autoTuneMemoryFromMetrics = async (item: ContentPlanItem, brand: BrandInfo): Promise<{ type: 'win' | 'flop', insight: string }> => {
  const ai = getAIClient();
  const metrics = item.metrics || { reach: 0, engagement: 0, roi: "$0" };
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze post performance for brand tuning.
    Post: "${item.title}"
    Prompt used: "${item.prompt}"
    Actual Metrics: Reach: ${metrics.reach}, Engagement: ${metrics.engagement}%, ROI: ${metrics.roi}
    
    Determine if this content is a "win" (high relative engagement) or a "flop".
    Provide a specific insight for why.
    
    Return JSON: { "type": "win" | "flop", "insight": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  
  try {
    return JSON.parse(response.text || '{"type": "flop", "insight": "No data."}');
  } catch (e) {
    return { type: 'flop', insight: "Analysis failed." };
  }
};

/**
 * Visual Continuity Engine
 * Analyzes the entire 7-day visual sequence for aesthetic harmony.
 */
export const evaluateVisualCohesion = async (plan: ContentPlanItem[], brand: BrandInfo): Promise<{ score: number, feedback: string, suggestedPalette: string[] }> => {
  const ai = getAIClient();
  const visualPrompts = plan.map(p => `Day ${p.day}: ${p.prompt}`).join('\n');
  
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Analyze these 7 visual prompts for brand cohesion:
    ${visualPrompts}
    
    Brand Style: ${brand.tone}
    
    Evaluate if the color palettes, lighting, and composition feel like a single brand or a mess.
    Return JSON: { "score": number, "feedback": "string", "suggestedPalette": ["hex", "hex"] }`,
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{"score": 50, "feedback": "Unable to sync.", "suggestedPalette": []}'); } catch (e) { return { score: 50, feedback: "Error", suggestedPalette: [] }; }
};

/**
 * Trend-Jack Interceptor
 * Scans Google Search for breaking news to "Hot-Swap" content.
 */
export const interceptTrendJack = async (brand: BrandInfo): Promise<{ trendFound: boolean, hook?: string, originalDayToReplace?: number, justification?: string } | null> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Find a massive breaking trend in the ${brand.industry} industry from the last 24 hours.
    If it's viral, suggest a way for ${brand.name} to 'jack' the trend.
    
    Return JSON: { "trendFound": boolean, "hook": "string", "justification": "string", "originalDayToReplace": number }`,
    config: { 
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json" 
    }
  });
  try { return JSON.parse(response.text || 'null'); } catch (e) { return null; }
};

/**
 * Multi-Factor Forensics
 * Breaks down the psychological levers of a hook.
 */
export const runHookForensics = async (item: ContentPlanItem): Promise<{ curiosity: number, urgency: number, socialProof: number, utility: number }> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze this hook: "${item.visualHook}". 
    Score 0-100 for: Curiosity, Urgency, SocialProof, Utility.
    Return JSON: { "curiosity": number, "urgency": number, "socialProof": number, "utility": number }`,
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{"curiosity": 50, "urgency": 50, "socialProof": 50, "utility": 50}'); } catch (e) { return { curiosity: 50, urgency: 50, socialProof: 50, utility: 50 }; }
};

/**
 * Strategic Echo: Content Strategy Generation with Memory Injection
 */
export const generateContentStrategy = async (brand: BrandInfo): Promise<ContentPlanItem[]> => {
  const ai = getAIClient();
  const memory = brand.memory || { winningPromptDNA: [], flopConstraints: [], industryInsights: [] };
  const successContext = memory.winningPromptDNA.length > 0 
    ? `PAST SUCCESS DNA (Replicate these structures): ${memory.winningPromptDNA.join(' | ')}` 
    : "No past data yet. Focus on high-energy hooks.";
  const failureContext = memory.flopConstraints.length > 0
    ? `AVOID THESE (Past flops): ${memory.flopConstraints.join(', ')}`
    : "";

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Act as a Social OS Engine. Create a 7-day high-conversion strategy for ${brand.name}. 
    Industry: ${brand.industry}
    Tone: ${brand.tone}
    ${successContext}
    ${failureContext}
    Return a JSON array of 7 ContentPlanItems.`,
    config: {
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            day: { type: Type.INTEGER },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            contentPillar: { type: Type.STRING },
            contentType: { type: Type.STRING },
            visualHook: { type: Type.STRING },
            script: { type: Type.STRING },
            prompt: { type: Type.STRING },
            caption: { type: Type.STRING },
            hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            platform: { type: Type.STRING }
          },
          required: ["day", "title", "description", "contentPillar", "contentType", "visualHook", "prompt", "caption", "hashtags", "platform"]
        }
      }
    }
  });
  try {
    return JSON.parse(response.text || '[]').map((item: any) => ({ 
      ...item, 
      status: 'pending',
      reasoning: "Strategy derived from Strategic Echo memory loop." 
    }));
  } catch (e) { return []; }
};

export const multiplexAsset = async (visualUrl: string, audioUrl?: string): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  return visualUrl;
};

export const simulateFocusGroup = async (item: ContentPlanItem, brand: BrandInfo): Promise<any[]> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Act as a Focus Group with 3 participants: 
    1. 'The Skeptic', 2. 'The Trend-Seeker', 3. 'The Ideal Client'.
    Post: "${item.title}" - Caption: "${item.caption}"
    Return JSON array: [{ "participant": string, "reaction": string, "score": number }]`,
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '[]'); } catch (e) { return []; }
};

export const geoAdaptContent = async (item: ContentPlanItem, location: string, brand: BrandInfo): Promise<any> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Adapt content for: ${location}. Brand: ${brand.name}. Return JSON: { caption, visualHook, justification }`,
    config: { tools: [{ googleMaps: {} }, { googleSearch: {} }] }
  });
  try {
    const jsonMatch = response.text?.match(/\{[\s\S]*\}/);
    return JSON.parse(jsonMatch ? jsonMatch[0] : response.text || '{}');
  } catch (e) { return {}; }
};

export const checkCompetitiveCollision = async (item: ContentPlanItem, brand: BrandInfo): Promise<{ isCollision: boolean, reason: string }> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Check competitive collision for: "${item.visualHook}" in ${brand.industry}. Return JSON.`,
    config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{"isCollision": false}'); } catch (e) { return { isCollision: false, reason: "" }; }
};

export const predictPerformance = async (item: ContentPlanItem, brand: BrandInfo, trends: Trend[]): Promise<number> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Predict virality score for "${item.title}". JSON {score: number}`,
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{"score": 50}').score; } catch (e) { return 50; }
};

export const runPostMortem = async (item: ContentPlanItem, success: boolean): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Meta-learning for ${success ? 'WIN' : 'FLOP'}: "${item.title}".`,
  });
  return response.text || "";
};

export const generateImageAsset = async (prompt: string, aspectRatio: string = "1:1"): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: { parts: [{ text: prompt }] },
    config: { imageConfig: { aspectRatio: aspectRatio as any } }
  });
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return `data:image/png;base64,${part?.inlineData?.data}`;
};

export const generatePersona = async (brand: BrandInfo): Promise<BrandPersona> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Persona for ${brand.name}. JSON.`,
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{}'); } catch (e) { return { name: "Alex", ageRange: "25-30", ethnicity: "Diverse", style: "Modern", backstory: "AI.", visualDescription: "Pro." }; }
};

export const researchCompetitors = async (brand: BrandInfo): Promise<BrandStrategy> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Analyze competitors for ${brand.name}. JSON.`,
    config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{}'); } catch (e) { return { competitors: [], suggestedThemes: [], visualDirection: "Modern." }; }
};

export const scanTrends = async (industry: string): Promise<Trend[]> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Trends for ${industry}. JSON.`,
    config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '[]'); } catch (e) { return []; }
};

export const generateVoiceover = async (text: string, voiceName: 'Kore' | 'Puck' | 'Zephyr' | 'Charon' = 'Zephyr'): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: { responseModalities: [Modality.AUDIO], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } } },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};

export const analyzeAsset = async (base64Data: string, mimeType: string): Promise<string[]> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: { parts: [{ inlineData: { data: base64Data.split(',')[1], mimeType } }, { text: "Tags JSON." }] },
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '[]'); } catch (e) { return []; }
};

/**
 * Image Editing via Gemini 2.5 Flash Image
 */
export const editImage = async (base64ImageData: string, mimeType: string, prompt: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64ImageData.includes(',') ? base64ImageData.split(',')[1] : base64ImageData,
            mimeType: mimeType,
          },
        },
        {
          text: prompt,
        },
      ],
    },
  });
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return part?.inlineData ? `data:image/png;base64,${part.inlineData.data}` : "";
};
