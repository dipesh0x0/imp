
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Asset } from '../types';
import { 
  Upload, Smartphone, Search, Image as ImageIcon, Film, 
  Plus, Database, Loader2, X, Box, Sparkles, Camera, 
  BrainCircuit, QrCode, Calendar, Info, Maximize2, Trash2, 
  Clock, Download, Share2, MoreHorizontal, RefreshCw, CheckCircle2
} from 'lucide-react';
import { analyzeAsset } from '../services/contentService';
import { useAuth } from '../context/AuthContext';

interface Props {
  assets: Asset[];
  onUpload: (asset: Asset) => void;
}

const AssetVault: React.FC<Props> = ({ assets, onUpload }) => {
  const { authenticatedFetch, user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic Session ID for Mobile Bridge
  const sessionId = useMemo(() => user?.id || 'guest-' + Math.random().toString(36).substr(2, 5), [user]);
  const mobileUploadLink = `https://contentpilot.app/mobile-upload?session=${sessionId}`;

  const filteredAssets = useMemo(() => {
    let result = [...assets];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a => 
        a.tags.some(t => t.toLowerCase().includes(q)) || 
        a.source.toLowerCase().includes(q)
      );
    }
    return result.sort((a, b) => b.createdAt - a.createdAt);
  }, [assets, searchQuery]);

  // Polling for Mobile Bridge Assets
  useEffect(() => {
    let pollInterval: number;

    const checkNewAssets = async () => {
      setIsPolling(true);
      try {
        const response = await authenticatedFetch(`/api/assets/check-new?session=${sessionId}`);
        if (response.ok) {
          const data = await response.json();
          if (data.newAssets && data.newAssets.length > 0) {
            data.newAssets.forEach((asset: Asset) => {
              // Avoid duplicates if already in list
              if (!assets.find(a => a.id === asset.id)) {
                onUpload(asset);
              }
            });
          }
        }
      } catch (err) {
        console.warn("Polling error", err);
      } finally {
        setIsPolling(false);
      }
    };

    // Start polling every 5 seconds
    pollInterval = window.setInterval(checkNewAssets, 5000);

    return () => clearInterval(pollInterval);
  }, [sessionId, assets, onUpload]);

  // REAL S3 UPLOAD LOGIC
  const handleFileChange = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsUploading(true);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      try {
        // 1. Get Presigned URL from Backend
        const urlRes = await authenticatedFetch('/api/assets/upload-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            fileName: file.name, 
            contentType: file.type 
          })
        });

        if (!urlRes.ok) throw new Error("Failed to get upload URL");
        const { uploadUrl, assetId, finalUrl } = await urlRes.json();

        // 2. PUT to S3 directly
        const uploadResponse = await fetch(uploadUrl, {
          method: 'PUT',
          body: file,
          headers: { 'Content-Type': file.type }
        });

        if (uploadResponse.ok) {
          // 3. Optional: Trigger Gemini Analysis on the uploaded file
          // For demo, we still use the local reader to get base64 for prompt-based analysis 
          // but we save the REAL S3 URL to the database
          const reader = new FileReader();
          await new Promise((resolve) => {
            reader.onload = async (event) => {
              const base64Data = event.target?.result as string;
              const tags = await analyzeAsset(base64Data, file.type.startsWith('video') ? 'image/png' : file.type);
              
              onUpload({
                id: assetId || Math.random().toString(36).substr(2, 9),
                url: finalUrl || base64Data, // Use the real S3 URL
                type: file.type.startsWith('video') ? 'video' : 'image',
                tags: [file.name, ...tags],
                source: 'upload',
                createdAt: Date.now()
              });
              resolve(null);
            };
            reader.readAsDataURL(file);
          });

          // 4. Notify backend upload is finished
          await authenticatedFetch(`/api/assets/confirm/${assetId}`, { method: 'POST' });
        }
      } catch (err) {
        console.error("Upload process failed", err);
      }
    }
    setIsUploading(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      
      {/* Mobile Bridge Banner */}
      <div className="relative overflow-hidden rounded-[3rem] bg-nixtio-black p-8 md:p-12 text-white shadow-2xl group">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-nixtio-purple/30 to-transparent pointer-events-none"></div>
        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-nixtio-purple/20 blur-[100px] rounded-full"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-md text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
              <Smartphone size={12} className="text-nixtio-soft"/>
              Mobile Sync 2.1 - Live Connection
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">Connect Mobile App</h2>
            <p className="text-sm text-nixtio-soft font-medium leading-relaxed">
              Upload raw B-Roll directly from your iPhone. Your session ID is <span className="text-white font-black">{sessionId}</span>. The library will sync automatically.
            </p>
            <div className="mt-6 flex items-center gap-4 justify-center md:justify-start">
               <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-xl border border-white/10">
                  <div className={`w-2 h-2 rounded-full ${isPolling ? 'bg-emerald-500 animate-pulse' : 'bg-nixtio-gray'}`}></div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-nixtio-soft">Polling Neural Bridge</span>
               </div>
            </div>
          </div>
          
          {/* Dynamic QR Code */}
          <div className="bg-white p-6 rounded-[2.5rem] shadow-2xl flex flex-col items-center gap-4 group-hover:scale-105 transition-transform duration-500">
             <div className="p-2 border-2 border-slate-100 rounded-2xl bg-nixtio-bg">
                <QrCode size={120} className="text-nixtio-black" />
             </div>
             <div className="text-center">
                <span className="text-[10px] font-black text-nixtio-black uppercase tracking-widest block">Scan to Install</span>
                <p className="text-[8px] text-nixtio-gray font-bold mt-1 max-w-[120px] truncate">{mobileUploadLink}</p>
             </div>
          </div>
        </div>
      </div>

      {/* Upload Zone */}
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-[3rem] p-12 text-center transition-all cursor-pointer overflow-hidden ${
          isDragging ? 'border-nixtio-purple bg-nixtio-purple/5' : 'border-nixtio-black/10 bg-white/40 hover:bg-white/60 hover:border-nixtio-purple'
        }`}
      >
        <input type="file" ref={fileInputRef} onChange={(e) => handleFileChange(e.target.files)} multiple accept="image/*,video/*" className="hidden" />
        <div className="flex flex-col items-center gap-4">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all ${isDragging ? 'bg-nixtio-purple text-white scale-110' : 'bg-white shadow-sm text-nixtio-gray'}`}>
            {isUploading ? <Loader2 size={24} className="animate-spin" /> : <Upload size={24} />}
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-nixtio-black uppercase tracking-widest">Real-time S3 Upload</h3>
            <p className="text-[10px] text-nixtio-gray mt-2 font-bold uppercase tracking-[0.1em]">Secure Endpoints • Multi-Part Parallel Sync</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="relative w-full lg:w-1/2">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
             <BrainCircuit className="text-nixtio-purple w-4 h-4" />
          </div>
          <input 
            className="w-full bg-white/60 border border-white rounded-2xl pl-12 pr-4 py-3.5 text-sm font-bold outline-none focus:ring-2 focus:ring-nixtio-purple transition-all shadow-sm" 
            placeholder="Search assets by vibe or tag..." 
            value={searchQuery} 
            onChange={(e) => setSearchQuery(e.target.value)} 
          />
        </div>
        <div className="flex items-center gap-3">
           {isPolling && <RefreshCw size={14} className="animate-spin text-nixtio-purple" />}
           <span className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest">{filteredAssets.length} Total Assets</span>
        </div>
      </div>

      {filteredAssets.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center glass-panel rounded-[3rem] border-dashed border-nixtio-black/10 bg-white/20">
           <Database size={48} className="text-nixtio-purple/20 mb-6" />
           <p className="text-sm font-bold text-nixtio-gray">Your library is empty. Start by syncing your phone or uploading files.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {filteredAssets.map(asset => (
            <div 
              key={asset.id} 
              onClick={() => setSelectedAsset(asset)}
              className="group relative aspect-square rounded-[2.5rem] overflow-hidden bg-white border-2 border-white hover:border-nixtio-purple hover:scale-[1.02] transition-all cursor-pointer shadow-sm"
            >
              {asset.type === 'video' ? <video src={asset.url} className="w-full h-full object-cover" /> : <img src={asset.url} className="w-full h-full object-cover" />}
              
              <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                 {asset.tags.slice(0, 2).map((tag, i) => (
                   <span key={i} className="px-2 py-0.5 bg-nixtio-black/60 backdrop-blur-md rounded-lg text-[7px] font-black text-white uppercase tracking-widest">
                     {tag.length > 10 ? tag.substring(0, 8) + '...' : tag}
                   </span>
                 ))}
                 {asset.source === 'mobile' && (
                   <span className="px-2 py-0.5 bg-nixtio-purple/80 backdrop-blur-md rounded-lg text-[7px] font-black text-white uppercase tracking-widest flex items-center gap-1">
                     <Smartphone size={8}/> Mobile
                   </span>
                 )}
              </div>

              <div className="absolute inset-0 bg-nixtio-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                 <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-xl border border-white/40 flex items-center justify-center text-white">
                    <Maximize2 size={18} />
                 </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Asset Detail Modal */}
      {selectedAsset && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10 animate-fade-in">
           <div className="absolute inset-0 bg-nixtio-black/60 backdrop-blur-xl" onClick={() => setSelectedAsset(null)}></div>
           
           <div className="relative w-full max-w-6xl h-full max-h-[85vh] bg-white rounded-[3.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row shadow-nixtio-purple/20 border border-white/20">
              
              {/* Full Size Preview */}
              <div className="flex-1 bg-nixtio-black flex items-center justify-center relative overflow-hidden">
                 {selectedAsset.type === 'video' ? (
                   <video src={selectedAsset.url} className="w-full h-full object-contain" controls autoPlay />
                 ) : (
                   <img src={selectedAsset.url} className="w-full h-full object-contain" />
                 )}
                 <button 
                  onClick={() => setSelectedAsset(null)}
                  className="absolute top-8 left-8 p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-all md:hidden"
                 >
                   <X size={20} />
                 </button>
              </div>

              {/* Sidebar Metadata */}
              <div className="w-full md:w-80 bg-white p-8 md:p-10 border-l border-nixtio-bg flex flex-col h-full">
                 <div className="flex items-center justify-between mb-8">
                    <h3 className="text-lg font-black text-nixtio-black uppercase tracking-tight">Metadata</h3>
                    <button onClick={() => setSelectedAsset(null)} className="p-2 text-nixtio-gray hover:text-nixtio-black transition-colors hidden md:block">
                       <X size={20} />
                    </button>
                 </div>

                 <div className="space-y-6 flex-1 overflow-y-auto custom-scroll pr-2">
                    <MetadataRow icon={<Info size={14}/>} label="Asset Type" value={selectedAsset.type === 'video' ? 'Pro Video (MP4)' : 'Image (PNG)'} />
                    <MetadataRow icon={<Maximize2 size={14}/>} label="Cloud Sync" value="S3 Edge-Node" />
                    {selectedAsset.type === 'video' && <MetadataRow icon={<Clock size={14}/>} label="Duration" value="00:15" />}
                    <MetadataRow icon={<Calendar size={14}/>} label="Date Created" value={new Date(selectedAsset.createdAt).toLocaleDateString()} />
                    <MetadataRow icon={<Database size={14}/>} label="Source" value={selectedAsset.source === 'upload' ? 'Desktop Upload' : 'Mobile Bridge'} />
                    
                    <div>
                       <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest block mb-4">Semantic Tags</span>
                       <div className="flex flex-wrap gap-2">
                          {selectedAsset.tags.map((tag, i) => (
                            <span key={i} className="px-3 py-1.5 bg-nixtio-bg rounded-xl text-[10px] font-bold text-nixtio-black border border-white">
                               {tag}
                            </span>
                          ))}
                       </div>
                    </div>
                 </div>

                 <div className="mt-8 pt-8 border-t border-nixtio-bg space-y-3">
                    <button className="w-full py-4 bg-nixtio-black text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-nixtio-purple transition-all shadow-cta">
                       <Download size={14}/> Download Asset
                    </button>
                    <div className="grid grid-cols-2 gap-3">
                       <button className="py-3 bg-nixtio-bg text-nixtio-black rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                          <Share2 size={14}/> Share
                       </button>
                       <button className="py-3 bg-red-50 text-red-500 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                          <Trash2 size={14}/> Delete
                       </button>
                    </div>
                 </div>
              </div>

           </div>
        </div>
      )}
    </div>
  );
};

const MetadataRow = ({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) => (
  <div className="flex flex-col gap-1.5">
     <div className="flex items-center gap-2 text-nixtio-gray">
        {icon}
        <span className="text-[9px] font-black uppercase tracking-widest">{label}</span>
     </div>
     <p className="text-xs font-bold text-nixtio-black">{value}</p>
  </div>
);

export default AssetVault;
