
import React from 'react';
import { BrandStrategy } from '../types';
import { Target, Search, BarChart3, ExternalLink, Zap, ShieldAlert, Link2, MapPin, Star, Loader2 } from 'lucide-react';

interface Props {
  strategy?: BrandStrategy;
  onReoptimize?: () => void;
  isReoptimizing?: boolean;
}

const CompetitorResearch: React.FC<Props> = ({ strategy, onReoptimize, isReoptimizing }) => {
  if (!strategy) return <div className="text-center py-20 font-bold text-nixtio-gray flex flex-col items-center gap-4"><BarChart3 className="animate-pulse" size={32}/> Running competitive engine...</div>;

  const mapsGrounding = strategy.groundingSources?.filter(s => s.uri?.includes('google.com/maps'));
  const webGrounding = strategy.groundingSources?.filter(s => !s.uri?.includes('google.com/maps'));

  return (
    <div className="space-y-12 animate-fade-in pb-20">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {strategy.competitors.length > 0 ? strategy.competitors.map((comp) => (
          <div key={comp.name} className="glass-panel p-8 rounded-[40px] border-white/60 bg-white/20 hover:bg-white/40 transition-all group flex flex-col">
            <div className="flex justify-between items-start mb-6">
               <div className="p-3 bg-nixtio-black text-white rounded-2xl shadow-lg"><Target size={20} /></div>
               {comp.url && (
                 <a href={comp.url} target="_blank" rel="noreferrer" className="p-2 bg-white/50 rounded-xl text-nixtio-gray hover:text-nixtio-black transition-colors"><ExternalLink size={16} /></a>
               )}
            </div>
            <h3 className="text-lg font-bold text-nixtio-black mb-1 uppercase tracking-tight">{comp.name}</h3>
            <p className="text-[10px] text-nixtio-gray font-bold uppercase tracking-widest mb-6">Market Competitor</p>
            
            <div className="space-y-4 mb-8 flex-1">
               <div className="space-y-1">
                  <span className="text-[9px] font-extrabold text-nixtio-purple uppercase tracking-tighter">Current Strategy</span>
                  <p className="text-sm text-nixtio-black font-medium leading-relaxed">{comp.strategy}</p>
               </div>
               <div className="space-y-1">
                  <span className="text-[9px] font-extrabold text-nixtio-gray uppercase tracking-tighter">Visual Hook</span>
                  <p className="text-xs text-nixtio-gray italic leading-relaxed">"{comp.visualHook}"</p>
               </div>
            </div>
            
            <div className="p-5 bg-emerald-500/5 border border-emerald-500/10 rounded-3xl group-hover:bg-emerald-500/10 transition-colors">
               <div className="flex items-center gap-2 mb-2">
                  <ShieldAlert size={14} className="text-emerald-600" />
                  <span className="text-[10px] font-bold text-emerald-700 uppercase">Growth Opportunity</span>
               </div>
               <p className="text-[11px] text-emerald-600 font-bold leading-tight">{comp.marketGap}</p>
            </div>
          </div>
        )) : (
          <div className="col-span-full h-48 flex items-center justify-center glass-panel rounded-[40px] border-dashed border-nixtio-black/10">
            <p className="text-sm font-bold text-nixtio-gray">Awaiting specific competitor research data...</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-7 space-y-8">
           <div className="glass-panel p-10 rounded-[40px] bg-nixtio-black text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10"><Zap size={120} /></div>
              <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center"><Zap size={20} fill="currentColor"/></div>
                  <h2 className="text-2xl font-extrabold tracking-tight">AI Strategic Themes</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {strategy.suggestedThemes.map((theme, i) => (
                    <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-[32px] hover:bg-white/10 transition-all hover:translate-x-1 cursor-default">
                      <span className="text-[10px] font-bold text-nixtio-soft uppercase tracking-widest mb-2 block">Theme Focus 0{i+1}</span>
                      <p className="text-sm font-bold leading-snug">{theme}</p>
                    </div>
                  ))}
              </div>
           </div>

           {/* Local Density Map / Maps Grounding */}
           {mapsGrounding && mapsGrounding.length > 0 && (
             <div className="glass-panel p-10 rounded-[40px] bg-white border-nixtio-purple/10 shadow-xl animate-fade-in">
                <div className="flex items-center justify-between mb-8">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-nixtio-purple/10 text-nixtio-purple flex items-center justify-center"><MapPin size={20}/></div>
                      <h3 className="text-lg font-bold text-nixtio-black">Local Density Engine</h3>
                   </div>
                   <span className="px-3 py-1 bg-nixtio-purple/10 text-nixtio-purple text-[10px] font-bold rounded-full uppercase">Google Maps Real-time</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                   {mapsGrounding.map((place, i) => (
                     <a 
                      key={i} 
                      href={place.uri} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="flex items-center gap-4 p-5 rounded-3xl bg-nixtio-bg/40 border border-white hover:border-nixtio-purple transition-all group"
                     >
                        <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-nixtio-purple shadow-sm group-hover:scale-110 transition-transform">
                          <MapPin size={18}/>
                        </div>
                        <div className="min-w-0 flex-1">
                           <p className="text-xs font-bold text-nixtio-black truncate mb-1">{place.title}</p>
                           <div className="flex items-center gap-1">
                              <Star size={10} className="fill-yellow-400 text-yellow-400"/>
                              <span className="text-[9px] font-bold text-nixtio-gray">Verified Local Entrant</span>
                           </div>
                        </div>
                        <ExternalLink size={14} className="text-nixtio-gray opacity-0 group-hover:opacity-100 transition-opacity" />
                     </a>
                   ))}
                </div>
             </div>
           )}
        </div>

        <div className="lg:col-span-5 flex flex-col gap-8">
          <div className="glass-panel p-10 rounded-[40px] border-nixtio-purple/20 bg-nixtio-purple/5 shadow-lg">
            <h3 className="text-lg font-bold text-nixtio-black mb-6 flex items-center gap-2"><BarChart3 className="text-nixtio-purple" size={20} /> Creative Identity</h3>
            <p className="text-sm text-nixtio-gray font-medium leading-relaxed mb-8 italic">"{strategy.visualDirection}"</p>
            <button 
              onClick={onReoptimize}
              disabled={isReoptimizing}
              className="w-full py-5 rounded-3xl bg-nixtio-black text-white font-bold text-xs uppercase tracking-widest shadow-cta hover:scale-[1.02] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
            >
              {/* Added Loader2 import to fix: Cannot find name 'Loader2'. */}
              {isReoptimizing ? <Loader2 size={16} className="animate-spin"/> : <Zap size={16} fill="white"/>} 
              {isReoptimizing ? 'Generating Visual Bridge...' : 'Re-Optimize Aesthetic'}
            </button>
          </div>

          {/* General Web Research Grounding */}
          {webGrounding && webGrounding.length > 0 && (
            <div className="glass-panel p-10 rounded-[40px] bg-white/60 border-white shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-[10px] font-extrabold text-nixtio-gray mb-0 uppercase tracking-widest">Grounding Intelligence</h3>
                <Search size={14} className="text-nixtio-gray"/>
              </div>
              <div className="space-y-3">
                {webGrounding.map((source, i) => (
                  <a 
                    key={i} 
                    href={source.uri} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center gap-4 p-4 rounded-3xl bg-white border border-nixtio-black/5 hover:border-nixtio-purple transition-all group shadow-sm"
                  >
                    <div className="w-9 h-9 rounded-xl bg-nixtio-purple/10 flex items-center justify-center text-nixtio-purple group-hover:bg-nixtio-purple group-hover:text-white transition-all shrink-0">
                      <Link2 size={16} />
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <p className="text-xs font-bold text-nixtio-black truncate mb-0.5">{source.title || 'Market Intelligence Snippet'}</p>
                      <p className="text-[9px] text-nixtio-gray truncate font-medium">{source.uri}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompetitorResearch;
