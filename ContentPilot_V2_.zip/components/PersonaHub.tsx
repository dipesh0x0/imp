
import React, { useState } from 'react';
import { BrandPersona, BrandInfo } from '../types';
import { User, Sparkles, Wand2, RefreshCw, Briefcase, Smile, Shirt, Info, Loader2, Check, Clock, Play, Film, Mic } from 'lucide-react';
import { generateImage, generatePersona, generateAvatarVideo } from '../services/contentService';
import { runWav2Lip } from '../services/externalServices';

interface Props {
  brand: BrandInfo;
  onUpdate: (persona: BrandPersona) => void;
}

const PersonaHub: React.FC<Props> = ({ brand, onUpdate }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [presenterClip, setPresenterClip] = useState<string | null>(null);

  const handleGeneratePersona = async () => {
    setIsGenerating(true);
    try {
      const newPersona = await generatePersona(brand);
      onUpdate(newPersona);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateAvatar = async () => {
    if (!brand.persona) return;
    setIsGeneratingImage(true);
    try {
      const result = await generateImage(`A high-end professional commercial portrait of ${brand.persona.visualDescription}, studio lighting, neutral background, 8k resolution`, "1:1");
      onUpdate({ ...brand.persona, avatarUrl: result.url });
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleAnimatePresenter = async () => {
    if (!brand.persona?.avatarUrl) return;
    setIsAnimating(true);
    try {
      // PRD 4.3: Lip-Sync Perfect integration
      const videoResult = await generateAvatarVideo(brand.persona, "Talking to the camera with professional hand gestures.");
      const syncedVideo = await runWav2Lip(videoResult.url, "https://api.contentpilot.ai/v1/voice/demo_ceo_vox.wav");
      console.log("PRD 4.3: Secondary Modification Layer (Wav2Lip) applied to Avatar.");
      setPresenterClip(syncedVideo);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnimating(false);
    }
  };

  const persona = brand.persona;

  return (
    <div className="space-y-10 animate-fade-in pb-20">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5 space-y-6">
           <div className="glass-panel p-2 rounded-[48px] bg-white border-white overflow-hidden shadow-2xl relative group">
              <div className="aspect-square bg-slate-100 rounded-[40px] overflow-hidden relative">
                {persona?.avatarUrl ? (
                  <img src={persona.avatarUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-nixtio-gray/20">
                    <User size={120} />
                  </div>
                )}
                {isGeneratingImage && (
                  <div className="absolute inset-0 bg-nixtio-black/60 backdrop-blur-sm flex flex-col items-center justify-center text-white">
                    <Loader2 size={48} className="animate-spin mb-4" />
                  </div>
                )}
              </div>
              <button 
                onClick={handleGenerateAvatar}
                disabled={!persona || isGeneratingImage}
                className="absolute bottom-8 left-8 right-8 py-5 bg-white/90 rounded-3xl font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl hover:bg-nixtio-black hover:text-white transition-all disabled:opacity-50"
              >
                {isGeneratingImage ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
                Generate AI Visual
              </button>
           </div>

           <div className="glass-panel p-8 rounded-[40px] bg-nixtio-black text-white overflow-hidden relative group">
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-nixtio-soft/20 flex items-center justify-center text-nixtio-soft"><Film size={20}/></div>
                    <div>
                       <h3 className="text-sm font-bold">Neural Presenter</h3>
                       <p className="text-[10px] text-nixtio-soft font-bold uppercase">PRD 4.3 Lip-Sync Perfect</p>
                    </div>
                 </div>
              </div>

              <div className="aspect-video bg-white/5 rounded-3xl mb-6 relative overflow-hidden flex items-center justify-center">
                 {presenterClip ? (
                    <video src={presenterClip} className="w-full h-full object-cover" autoPlay muted loop />
                 ) : (
                    <p className="text-[10px] text-white/40 uppercase tracking-widest">Awaiting Hybrid Sync</p>
                 )}
                 {isAnimating && (
                    <div className="absolute inset-0 bg-nixtio-black/80 backdrop-blur-md flex flex-col items-center justify-center">
                       <Loader2 size={32} className="animate-spin mb-3 text-nixtio-soft" />
                    </div>
                 )}
              </div>

              <button 
                onClick={handleAnimatePresenter}
                disabled={!persona?.avatarUrl || isAnimating}
                className="w-full py-4 rounded-2xl bg-white text-nixtio-black font-bold text-[10px] uppercase tracking-widest hover:bg-nixtio-soft transition-all flex items-center justify-center gap-2"
              >
                 <Play size={14} fill="currentColor"/>
                 Animate Sync (Modal Stack)
              </button>
           </div>
        </div>

        <div className="lg:col-span-7 space-y-8">
           <div>
              <h2 className="text-3xl font-bold text-nixtio-black tracking-tight">AI Persona Engine</h2>
              <p className="text-nixtio-gray font-medium">Define the virtual face and voice of your brand.</p>
           </div>

           {persona && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <DetailCard icon={<Smile className="text-nixtio-purple"/>} label="Profile Name" value={persona.name} />
                <DetailCard icon={<Clock className="text-emerald-500"/>} label="Age Range" value={persona.ageRange} />
                <DetailCard icon={<Briefcase className="text-orange-500"/>} label="Occupation" value={brand.industry + " Expert"} />
                <DetailCard icon={<Shirt className="text-blue-500"/>} label="Visual Style" value={persona.style} />
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

const DetailCard = ({ icon, label, value }: any) => (
  <div className="glass-panel p-6 rounded-[28px] bg-white/60 border-white hover:border-nixtio-purple/30 transition-all group">
     <div className="flex items-center gap-3 mb-3">
        <div className="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center">{icon}</div>
        <span className="text-[10px] font-bold text-nixtio-gray uppercase tracking-widest">{label}</span>
     </div>
     <p className="text-sm font-bold text-nixtio-black group-hover:text-nixtio-purple transition-colors">{value}</p>
  </div>
);

export default PersonaHub;
