
import React, { useState, useMemo } from 'react';
import { ContentPlanItem, Platform } from '../types';
import { 
  Calendar as CalendarIcon, List, ChevronLeft, ChevronRight, 
  Clock, ShieldCheck, MoreHorizontal, Instagram, Linkedin, 
  Twitter, Plus, Info, Zap, GripVertical, 
  LayoutGrid, CalendarDays, Loader2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface Props {
  plan: ContentPlanItem[];
  onSchedule: (day: number, date: number) => void;
}

const Campaigns: React.FC<Props> = ({ plan, onSchedule }) => {
  const { authenticatedFetch } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const [isScheduling, setIsScheduling] = useState(false);

  const daysInMonth = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const date = new Date(year, month, 1);
    const days = [];
    
    // Padding for first day of week
    const firstDay = date.getDay();
    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }
    
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  const scheduledPosts = plan.filter(p => p.status === 'scheduled' || p.status === 'published');
  const draftPosts = plan.filter(p => p.status === 'pending' || p.status === 'completed' || p.status === 'draft');

  const getPostsForDate = (date: Date) => {
    return scheduledPosts.filter(p => {
      if (!p.scheduledAt) return false;
      const d = new Date(p.scheduledAt);
      return d.getDate() === date.getDate() && 
             d.getMonth() === date.getMonth() && 
             d.getFullYear() === date.getFullYear();
    });
  };

  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));

  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  // REAL API CALL: PERSIST SCHEDULE
  const handlePersistSchedule = async (day: number, timestamp: number) => {
    setIsScheduling(true);
    try {
      const response = await authenticatedFetch('/api/campaigns/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ day, scheduledAt: timestamp })
      });

      if (response.ok) {
        onSchedule(day, timestamp);
      } else {
        console.error("Failed to schedule post on backend");
        // Opt-in for a temporary local update even if fail for UX? 
        // No, let's stick to the prompt's direction.
      }
    } catch (err) {
      console.error("Schedule Persistence Error", err);
    } finally {
      setIsScheduling(false);
    }
  };

  const handleSmartSchedule = async () => {
    setIsScheduling(true);
    try {
      // Logic for batch scheduling all drafts via AI
      const response = await authenticatedFetch('/api/campaigns/smart-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ daysToSchedule: draftPosts.map(d => d.day) })
      });
      
      if (response.ok) {
        const results = await response.json();
        results.forEach((res: any) => onSchedule(res.day, res.scheduledAt));
      }
    } catch (err) {
      console.error("Smart Schedule Error", err);
    } finally {
      setIsScheduling(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-6 animate-fade-in overflow-hidden">
      
      {/* Header & Controls */}
      <div className="flex items-center justify-between shrink-0">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <button onClick={prevMonth} className="p-2 hover:bg-white rounded-xl transition-all"><ChevronLeft size={18}/></button>
            <h2 className="text-xl font-black text-nixtio-black tracking-tight min-w-[140px] text-center">
              {monthName} <span className="text-nixtio-gray/40">{currentDate.getFullYear()}</span>
            </h2>
            <button onClick={nextMonth} className="p-2 hover:bg-white rounded-xl transition-all"><ChevronRight size={18}/></button>
          </div>
          <div className="h-8 w-px bg-nixtio-black/5"></div>
          <div className="flex bg-white/60 p-1 rounded-2xl border border-white">
            <button 
              onClick={() => setViewMode('calendar')} 
              className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'calendar' ? 'bg-nixtio-black text-white shadow-lg' : 'text-nixtio-gray hover:text-nixtio-black'}`}
            >
              <CalendarDays size={14}/> Calendar
            </button>
            <button 
              onClick={() => setViewMode('list')} 
              className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-nixtio-black text-white shadow-lg' : 'text-nixtio-gray hover:text-nixtio-black'}`}
            >
              <List size={14}/> Queue
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2">
             <ShieldCheck size={14} className="text-emerald-500" />
             <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">±4m Jitter Active</span>
          </div>
          <button className="px-6 py-3 bg-nixtio-black text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-cta hover:bg-nixtio-purple transition-all flex items-center gap-2">
             <Plus size={14}/> Manual Schedule
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-12 gap-8 min-h-0 overflow-hidden">
        
        {/* Main Content Area: Split View */}
        <div className="col-span-12 lg:col-span-9 flex flex-col gap-8 h-full min-h-0">
          
          {/* Top Half: Calendar Grid */}
          <div className="flex-1 bg-white/40 backdrop-blur-xl rounded-[3rem] border border-white/60 p-8 shadow-sm overflow-hidden flex flex-col">
            <div className="grid grid-cols-7 mb-4 border-b border-nixtio-black/5 pb-4">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center text-[10px] font-black text-nixtio-gray uppercase tracking-widest">{day}</div>
              ))}
            </div>
            <div className="flex-1 grid grid-cols-7 gap-1 overflow-y-auto custom-scroll pr-2">
              {daysInMonth.map((date, idx) => {
                if (!date) return <div key={`empty-${idx}`} className="aspect-square"></div>;
                const posts = getPostsForDate(date);
                const isToday = new Date().toDateString() === date.toDateString();
                
                return (
                  <div 
                    key={date.toISOString()} 
                    className={`aspect-square p-2 border border-white/20 rounded-2xl transition-all relative group flex flex-col ${isToday ? 'bg-nixtio-purple/5 ring-1 ring-nixtio-purple/20' : 'bg-white/20 hover:bg-white/60'}`}
                  >
                    <span className={`text-[10px] font-black ${isToday ? 'text-nixtio-purple' : 'text-nixtio-gray'} mb-2`}>
                      {date.getDate()}
                    </span>
                    <div className="flex-1 flex flex-wrap gap-1 content-start">
                      {posts.map(post => (
                        <div key={post.day} className="w-full group/post relative">
                           <div className="flex items-center gap-1.5 px-2 py-1.5 bg-nixtio-black rounded-lg text-white shadow-sm overflow-hidden">
                              <PlatformIcon platform={post.platform} />
                              <span className="text-[7px] font-bold truncate flex-1">{post.title}</span>
                           </div>
                           {/* Post Preview Tooltip on Hover */}
                           <div className="absolute bottom-full left-0 mb-2 w-48 bg-nixtio-black text-white p-3 rounded-2xl opacity-0 pointer-events-none group-hover/post:opacity-100 transition-opacity z-50 shadow-2xl scale-95 group-hover/post:scale-100">
                              <p className="text-[8px] font-black uppercase tracking-widest text-nixtio-soft mb-1">Preview</p>
                              <p className="text-[10px] font-bold leading-tight mb-2 line-clamp-2">{post.title}</p>
                              <div className="flex items-center gap-2">
                                <Clock size={10} className="text-nixtio-soft" />
                                <span className="text-[9px] font-bold">Scheduled: 09:00 AM</span>
                              </div>
                           </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Half: Queue List */}
          <div className="h-1/3 bg-white/60 backdrop-blur-xl rounded-[3rem] border border-white p-8 shadow-sm flex flex-col min-h-[200px]">
             <div className="flex items-center justify-between mb-6">
                <h3 className="text-sm font-black text-nixtio-black uppercase tracking-tight flex items-center gap-2">
                  <Clock size={16} className="text-nixtio-purple" /> Production Queue
                </h3>
                <span className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest">{scheduledPosts.length} Items Scheduled</span>
             </div>
             <div className="flex-1 overflow-y-auto custom-scroll space-y-3 pr-2">
                {scheduledPosts.map(post => (
                  <div key={post.day} className="flex items-center gap-4 p-4 bg-white rounded-3xl border border-nixtio-black/5 hover:border-nixtio-purple/30 transition-all shadow-sm group">
                     <div className="w-12 h-12 rounded-xl bg-slate-950 overflow-hidden relative shrink-0">
                        {post.assetUrl && <img src={post.assetUrl} className="w-full h-full object-cover" />}
                        <div className="absolute inset-0 bg-nixtio-purple/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                           <PlatformIcon platform={post.platform} size={14} />
                        </div>
                     </div>
                     <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-nixtio-black truncate">{post.title}</h4>
                        <div className="flex items-center gap-3 mt-1">
                           <div className="flex items-center gap-1.5">
                              <CalendarIcon size={12} className="text-nixtio-gray" />
                              <span className="text-[10px] font-bold text-nixtio-gray">{new Date(post.scheduledAt || 0).toLocaleDateString()}</span>
                           </div>
                           <div className="flex items-center gap-1.5">
                              <Clock size={12} className="text-nixtio-purple" />
                              <span className="text-[10px] font-black text-nixtio-purple uppercase tracking-widest">09:00 AM <span className="text-[8px] opacity-60">(±4m)</span></span>
                           </div>
                        </div>
                     </div>
                     <div className="flex items-center gap-2">
                        <button className="p-2 text-nixtio-gray hover:text-nixtio-black hover:bg-nixtio-bg rounded-xl transition-all">
                           <Info size={16} />
                        </button>
                        <button className="p-2 text-nixtio-gray hover:text-red-500 hover:bg-red-50 rounded-xl transition-all">
                           <MoreHorizontal size={16} />
                        </button>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Right Column: Drafts / Sidebar */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-6 h-full min-h-0">
           <div className="flex-1 bg-white p-8 rounded-[3.5rem] border border-white shadow-xl flex flex-col overflow-hidden">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-sm font-black text-nixtio-black uppercase tracking-tight">Strategy Drafts</h3>
                <div className="p-2 bg-nixtio-bg rounded-xl">
                   <GripVertical size={16} className="text-nixtio-gray/40" />
                </div>
              </div>

              <div className="flex-1 overflow-y-auto custom-scroll space-y-4 pr-1">
                 {draftPosts.length === 0 ? (
                   <div className="h-full flex flex-col items-center justify-center text-center p-6 opacity-20 grayscale">
                      <Zap size={48} className="mb-4" />
                      <p className="text-[10px] font-black uppercase tracking-widest">No Drafts Ready</p>
                   </div>
                 ) : (
                   draftPosts.map(post => (
                     <div 
                      key={post.day} 
                      draggable 
                      className="p-5 rounded-3xl bg-nixtio-bg/50 border border-white hover:border-nixtio-purple/50 hover:bg-white hover:shadow-lg transition-all cursor-grab active:cursor-grabbing group"
                     >
                        <div className="flex items-center justify-between mb-3">
                           <span className="text-[9px] font-black text-nixtio-purple uppercase tracking-widest">{post.contentPillar}</span>
                           <PlatformIcon platform={post.platform} className="text-nixtio-gray" />
                        </div>
                        <h4 className="text-xs font-bold text-nixtio-black leading-tight mb-4">{post.title}</h4>
                        <div className="flex items-center justify-between">
                           <div className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full"></div>
                              <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest">Ready to Pin</span>
                           </div>
                           <button 
                            onClick={() => handlePersistSchedule(post.day, Date.now() + 86400000)} // Mock schedule for tomorrow
                            disabled={isScheduling}
                            className="p-2 opacity-0 group-hover:opacity-100 text-nixtio-purple transition-opacity disabled:opacity-30"
                           >
                              {isScheduling ? <Loader2 size={16} className="animate-spin"/> : <Plus size={16} />}
                           </button>
                        </div>
                     </div>
                   ))
                 )}
              </div>

              <div className="mt-8 pt-8 border-t border-nixtio-bg">
                 <div className="p-6 bg-slate-900 rounded-[2.5rem] text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><Zap size={48}/></div>
                    <p className="text-[10px] font-black text-nixtio-soft uppercase tracking-widest mb-2">Power Move</p>
                    <p className="text-xs font-bold leading-relaxed mb-4">Auto-schedule remaining {draftPosts.length} drafts using AI peak times?</p>
                    <button 
                      onClick={handleSmartSchedule}
                      disabled={isScheduling || draftPosts.length === 0}
                      className="w-full py-3 bg-white text-nixtio-black rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-nixtio-soft transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                       {isScheduling && <Loader2 size={14} className="animate-spin" />}
                       Smart Schedule
                    </button>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const PlatformIcon = ({ platform, size = 12, className = "" }: { platform: Platform, size?: number, className?: string }) => {
  switch (platform) {
    case Platform.Instagram: return <Instagram size={size} className={className} />;
    case Platform.LinkedIn: return <Linkedin size={size} className={className} />;
    case Platform.Twitter: return <Twitter size={size} className={className} />;
    default: return <LayoutGrid size={size} className={className} />;
  }
};

export default Campaigns;
