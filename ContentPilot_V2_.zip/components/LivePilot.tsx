
import React, { useState, useEffect, useRef } from 'react';
import { Mic, X, Wifi, BrainCircuit, Waves, Loader2, User, Bot } from 'lucide-react';
import { getAIClient } from '../services/geminiService';
import { Modality, LiveServerMessage } from '@google/genai';
import { GenerationState } from '../types';

interface Props {
  onClose: () => void;
  state: GenerationState;
}

const LivePilot: React.FC<Props> = ({ onClose, state }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [currentTranscript, setCurrentTranscript] = useState({ user: '', ai: '' });
  const [history, setHistory] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [currentTranscript, history]);

  const encodePCM = (data: Float32Array): string => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    const bytes = new Uint8Array(int16.buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decodeBase64 = (base64: string) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    return buffer;
  };

  const startLiveSession = async () => {
    setIsConnecting(true);
    const ai = getAIClient();
    
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const inputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      alert("Microphone access is required for the Live Pilot.");
      setIsConnecting(false);
      return;
    }

    const planContext = state.plan.map(p => `Day ${p.day}: ${p.title} (${p.platform})`).join('\n');

    const sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-09-2025',
      callbacks: {
        onopen: () => {
          setIsActive(true);
          setIsConnecting(false);
          
          const source = inputContext.createMediaStreamSource(streamRef.current!);
          const scriptProcessor = inputContext.createScriptProcessor(4096, 1, 1);
          scriptProcessor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const base64 = encodePCM(inputData);
            sessionPromise.then(session => {
              session.sendRealtimeInput({ media: { data: base64, mimeType: 'audio/pcm;rate=16000' } });
            });
          };
          source.connect(scriptProcessor);
          scriptProcessor.connect(inputContext.destination);
        },
        onmessage: async (message: LiveServerMessage) => {
          // Audio Output Handling
          if (message.serverContent?.modelTurn?.parts[0]?.inlineData?.data) {
            const audioData = decodeBase64(message.serverContent.modelTurn.parts[0].inlineData.data);
            const ctx = audioContextRef.current!;
            const audioBuffer = await decodeAudioData(audioData, ctx);
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += audioBuffer.duration;
          }

          // Real-time Transcription Handling
          if (message.serverContent?.inputTranscription) {
            const text = message.serverContent.inputTranscription.text;
            setCurrentTranscript(prev => ({ ...prev, user: text }));
          } else if (message.serverContent?.outputTranscription) {
            const text = message.serverContent.outputTranscription.text;
            setCurrentTranscript(prev => ({ ...prev, ai: prev.ai + text }));
          }

          // Turn Completion Handling
          if (message.serverContent?.turnComplete) {
            setCurrentTranscript(prev => {
              const newHistory = [...history];
              if (prev.user) newHistory.push({ role: 'user', text: prev.user });
              if (prev.ai) newHistory.push({ role: 'ai', text: prev.ai });
              setHistory(newHistory);
              return { user: '', ai: '' };
            });
          }
          
          // Interruption Handling
          if (message.serverContent?.interrupted) {
            nextStartTimeRef.current = 0;
            // Clear current AI transcript if interrupted
            setCurrentTranscript(prev => ({ ...prev, ai: '' }));
          }
        },
        onclose: () => setIsActive(false),
        onerror: (e) => {
          console.error("Live session error:", e);
          setIsConnecting(false);
          setIsActive(false);
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        systemInstruction: `You are the ContentPilot Spatial Assistant. Help the user optimize their strategy.
        CONTEXT:
        ${planContext}
        
        Guidelines:
        1. Keep responses snappy and focused on social media growth.
        2. Reference specific days in the plan.
        3. Be conversational but professional.`
      }
    });

    sessionRef.current = await sessionPromise;
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    setIsActive(false);
    setIsConnecting(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-nixtio-black/60 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-xl glass-panel p-8 md:p-10 rounded-[48px] bg-white relative shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-nixtio-purple to-emerald-500"></div>
        
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${isActive ? 'bg-emerald-500 text-white animate-pulse' : 'bg-nixtio-black text-white'}`}>
              <BrainCircuit size={20} />
            </div>
            <div>
              <h2 className="text-lg font-black text-nixtio-black uppercase tracking-tight">Spatial Pilot</h2>
              <div className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest">
                  {isActive ? 'Neural Link Active' : isConnecting ? 'Establishing Link...' : 'Link Disconnected'}
                </span>
              </div>
            </div>
          </div>
          <button onClick={() => { stopSession(); onClose(); }} className="p-2 rounded-full hover:bg-slate-100 transition-colors text-nixtio-gray">
            <X size={20} />
          </button>
        </div>

        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto custom-scroll space-y-4 mb-8 pr-2 min-h-[200px]"
        >
          {history.length === 0 && !currentTranscript.user && !currentTranscript.ai && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-10">
              <Waves size={40} className="mb-4 text-nixtio-purple" />
              <p className="text-xs font-bold uppercase tracking-widest text-nixtio-gray">Awaiting Neural Input...</p>
            </div>
          )}

          {history.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-fade-in`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-nixtio-purple text-white' : 'bg-slate-900 text-white'}`}>
                {msg.role === 'user' ? <User size={14}/> : <Bot size={14}/>}
              </div>
              <div className={`max-w-[80%] p-4 rounded-2xl text-xs font-bold leading-relaxed ${msg.role === 'user' ? 'bg-nixtio-purple/5 text-nixtio-black border border-nixtio-purple/10' : 'bg-slate-50 text-nixtio-black border border-slate-100'}`}>
                {msg.text}
              </div>
            </div>
          ))}

          {currentTranscript.user && (
            <div className="flex gap-3 flex-row-reverse animate-pulse">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 bg-nixtio-purple text-white opacity-50">
                <User size={14}/>
              </div>
              <div className="max-w-[80%] p-4 rounded-2xl text-xs font-bold leading-relaxed bg-nixtio-purple/10 text-nixtio-black/60 italic border border-nixtio-purple/20">
                {currentTranscript.user}...
              </div>
            </div>
          )}

          {currentTranscript.ai && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 bg-slate-900 text-white">
                <Bot size={14}/>
              </div>
              <div className="max-w-[80%] p-4 rounded-2xl text-xs font-bold leading-relaxed bg-slate-100 text-nixtio-black border border-slate-200">
                {currentTranscript.ai}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-4 bg-nixtio-bg/40 p-6 rounded-[32px] border border-white">
           <button 
              onClick={isActive ? stopSession : startLiveSession}
              disabled={isConnecting}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 shadow-xl relative overflow-hidden group ${isActive ? 'bg-red-500 scale-110' : 'bg-nixtio-black hover:bg-nixtio-purple disabled:opacity-50'}`}
           >
              {isConnecting ? (
                <Loader2 size={24} className="text-white animate-spin" />
              ) : isActive ? (
                <Waves className="text-white animate-pulse" size={24} />
              ) : (
                <Mic className="text-white group-hover:scale-110 transition-transform" size={24} />
              )}
           </button>
           <div className="text-center">
              <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-[0.2em]">
                {isActive ? 'Neural Link Established' : isConnecting ? 'Synchronizing Waves' : 'Initiate Neural Link'}
              </span>
              {isActive && (
                <p className="text-[10px] text-emerald-600 font-bold uppercase mt-1 animate-pulse">Assistant is listening...</p>
              )}
           </div>
        </div>
      </div>
    </div>
  );
};

export default LivePilot;
