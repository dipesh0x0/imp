
import React, { useState, useEffect } from 'react';
import { ContentPlanItem, BrandInfo } from '../types';
import { 
  TrendingUp, Users, DollarSign, ArrowUpRight, CheckCircle2, Calendar,
  ShieldCheck, Wifi, Clock, Lock, Info, AlertTriangle, ShieldAlert, Check,
  Zap, Loader2, RefreshCw, Database
} from 'lucide-react';
import { fetchLiveMetrics, syncMemoryToPinecone } from '../services/externalServices';
import { autoTuneMemoryFromMetrics } from '../services/geminiService';

interface Props {
  plan: ContentPlanItem[];
  brandInfo?: BrandInfo;
  onUpdateBrand?: (brand: BrandInfo) => void;
}

const Publisher: React.FC<Props> = ({ plan, brandInfo, onUpdateBrand }) => {
  const [publishedItems, setPublishedItems] = useState(plan.filter(i => i.status === 'published'));
  const [isSyncing, setIsSyncing] = useState(false);
  const [proxyNode] = useState('US-WEST-RESIDENTIAL-09');
  
  const calculateJitter = () => {
     return (Math.random() * 8 - 4) * 60 * 1000;
  };

  const handleSyncAnalytics = async () => {
    setIsSyncing(true);
    try {
      const updated = await Promise.all(publishedItems.map(async (item) => {
        const liveData = await fetchLiveMetrics(`post_${item.day}`);
        if (liveData) {
           const updatedItem = { ...item, metrics: { ...item.metrics, ...liveData } };
           
           // PRD 3.1: Auto-Tuning Loop
           if (brandInfo && onUpdateBrand) {
              const tuning = await autoTuneMemoryFromMetrics(updatedItem, brandInfo);
              const currentMemory = brandInfo.memory || { winningPromptDNA: [], flopConstraints: [], industryInsights: [] };
              
              const updatedMemory = {
                ...currentMemory,
                winningPromptDNA: tuning.type === 'win' ? [...currentMemory.winningPromptDNA, item.prompt].slice(-10) : currentMemory.winningPromptDNA,
                flopConstraints: tuning.type === 'flop' ? [...currentMemory.flopConstraints, item.contentPillar].slice(-10) : currentMemory.flopConstraints,
                industryInsights: [...currentMemory.industryInsights, tuning.insight].slice(-5)
              };

              onUpdateBrand({ ...brandInfo, memory: updatedMemory });
              syncMemoryToPinecone(brandInfo.name, updatedMemory).catch(console.error);
           }
           
           return updatedItem;
        }
        return item;
      }));
      setPublishedItems(updated as any);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    if (publishedItems.length > 0) {
      handleSyncAnalytics();
    }
  }, []);

  return (
    <div className="space-y-10 animate-fade-in">
      <div className="glass-panel p-6 rounded-[32px] bg-slate-900 border-white/5 flex flex-wrap gap-8 items-center justify-between text-white shadow-xl">
         <div className="flex gap-10">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500"><Wifi size={18}/></div>
               <div>
                  <p className="text-[8px] font-black uppercase text-slate-500">Residential Proxy</p>
                  <p className="text-xs font-bold text-emerald-500">Node: {proxyNode}</p>
               </div>
            </div>
            <div className="flex items-center gap-3">
               <div className="p-2 bg-nixtio-purple/10 rounded-lg text-nixtio-purple"><Clock size={18}/></div>
               <div>
                  <p className="text-[8px] font-black uppercase text-slate-500">Publishing Jitter</p>
                  <p className="text-xs font-bold text-nixtio-soft">Enabled: +/- 4m Randomize</p>
               </div>
            </div>
            <div className="flex items-center gap-3">
               <div className="p-2 bg-yellow-500/10 rounded-lg text-yellow-500"><ShieldCheck size={18}/></div>
               <div>
                  <p className="text-[8px] font-black uppercase text-slate-500">Deepfake Prevention</p>
                  <p className="text-xs font-bold text-yellow-500">Active: Invisi-Watermark</p>
               </div>
            </div>
         </div>
         <button 
           onClick={handleSyncAnalytics}
           disabled={isSyncing}
           className="flex items-center gap-2 px-6 py-2.5 bg-white text-nixtio-black rounded-2xl text-[9px] font-black uppercase tracking-widest hover:bg-nixtio-soft transition-all disabled:opacity-50"
         >
            {isSyncing ? <RefreshCw size={14} className="animate-spin" /> : <Database size={14}/>}
            {isSyncing ? 'Auto-Tuning Memory...' : 'Sync Live Metrics'}
         </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard icon={<Users className="text-nixtio-purple"/>} label="Network Reach" value="24.8K" trend="+12%" />
        <MetricCard icon={<TrendingUp className="text-emerald-500"/>} label="Engagement Rate" value="4.2%" trend="+0.8%" />
        <MetricCard icon={<DollarSign className="text-yellow-600"/>} label="Attributed ROI" value="$1,240" trend="+18%" />
        <MetricCard icon={<CheckCircle2 className="text-nixtio-black"/>} label="Batch Success" value="100%" trend="Stable" />
      </div>

      <div className="glass-panel p-10 rounded-[40px] bg-white">
        <div className="flex justify-between items-center mb-8">
           <h3 className="text-lg font-bold text-nixtio-black">Deployment Feed</h3>
           <div className="flex items-center gap-2 px-3 py-1 bg-nixtio-bg rounded-lg text-[9px] font-bold text-nixtio-gray uppercase">
              <Zap size={12}/> Background Task Runner: BullMQ Active
           </div>
        </div>
        
        <div className="space-y-4">
          {publishedItems.length === 0 ? (
            <div className="py-20 text-center flex flex-col items-center gap-4 border-2 border-dashed border-nixtio-black/5 rounded-[32px]">
                <Calendar className="text-nixtio-gray opacity-20" size={48} />
                <p className="text-sm font-bold text-nixtio-gray">Awaiting scheduled triggers from Command OS.</p>
            </div>
          ) : (
            publishedItems.map((item) => (
              <div key={item.day} className="flex items-center gap-6 p-6 rounded-[28px] bg-nixtio-bg/40 border border-white hover:border-nixtio-purple/20 transition-all">
                <div className="w-16 h-16 rounded-2xl bg-nixtio-black shrink-0 overflow-hidden relative group">
                   {item.assetUrl && <img src={item.assetUrl} className="w-full h-full object-cover" />}
                   <div className="absolute inset-0 bg-emerald-500/20 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                      <Lock size={20} className="text-white" />
                   </div>
                </div>
                <div className="flex-1">
                    <h4 className="text-sm font-bold text-nixtio-black">{item.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                       <p className="text-[10px] text-nixtio-gray font-bold uppercase tracking-widest">{item.platform}</p>
                       <span className="text-[10px] text-nixtio-soft font-bold">•</span>
                       <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest flex items-center gap-1">
                          <Check size={10}/> Proxied via {proxyNode}
                       </p>
                    </div>
                </div>
                <div className="hidden md:flex gap-10">
                    <div className="text-center">
                        <span className="text-[9px] font-bold text-nixtio-gray uppercase block">Impression</span>
                        <span className="text-xs font-bold text-nixtio-black">{item.metrics?.reach.toLocaleString() || '0'}</span>
                    </div>
                    <div className="text-center">
                        <span className="text-[9px] font-bold text-nixtio-gray uppercase block">Eng. Rank</span>
                        <span className="text-xs font-bold text-nixtio-black">{item.metrics?.engagement || '0'}%</span>
                    </div>
                </div>
                <div className="flex flex-col items-end">
                   <div className="p-3 bg-white rounded-full text-nixtio-purple mb-1">
                      <ArrowUpRight size={16} />
                   </div>
                   <span className="text-[8px] font-black text-nixtio-gray uppercase">
                      Jitter Apply: {Math.floor(calculateJitter() / 1000)}s
                   </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({ icon, label, value, trend }: any) => (
  <div className="glass-panel p-8 rounded-[32px] bg-white/60 border-white">
     <div className="w-10 h-10 rounded-xl bg-white border border-nixtio-black/5 flex items-center justify-center mb-6">
        {icon}
     </div>
     <p className="text-[10px] font-bold text-nixtio-gray uppercase tracking-widest mb-1">{label}</p>
     <div className="flex items-end justify-between">
        <h4 className="text-2xl font-black text-nixtio-black">{value}</h4>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${trend.includes('+') ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'}`}>{trend}</span>
     </div>
  </div>
);

export default Publisher;
