
import React, { useState } from 'react';
import { BrandInfo, BrandGuardrails } from '../types';
// Added Loader2 to fix: Cannot find name 'Loader2'.
import { 
  User, Sparkles, Mic, Palette, ShieldAlert, 
  Save, Video, Image as ImageIcon, Plus, X, 
  Info, Sliders, Type, Target, Heart, Zap,
  Upload, Trash2, CheckCircle2, AlertTriangle,
  Loader2
} from 'lucide-react';

interface Props {
  brand: BrandInfo;
  onUpdate: (brand: BrandInfo) => void;
}

const Settings: React.FC<Props> = ({ brand, onUpdate }) => {
  const [activeTab, setActiveTab] = useState<'voice' | 'visual' | 'guardrails' | 'avatar'>('voice');
  const [localBrand, setLocalBrand] = useState<BrandInfo>({
    ...brand,
    riskLevel: brand.riskLevel || 'Medium',
    brandColors: brand.brandColors || ['#05060B', '#6C72AC', '#9CA7DE'],
    guardrails: brand.guardrails || { negativeKeywords: [], toneConstraints: [], legalDisclaimers: [] }
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [newKeyword, setNewKeyword] = useState('');

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      onUpdate(localBrand);
      setIsSaving(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1200);
  };

  const addKeyword = () => {
    if (!newKeyword.trim()) return;
    const updated = {
      ...localBrand,
      guardrails: {
        ...localBrand.guardrails!,
        negativeKeywords: [...(localBrand.guardrails?.negativeKeywords || []), newKeyword.trim()]
      }
    };
    setLocalBrand(updated);
    setNewKeyword('');
  };

  const removeKeyword = (index: number) => {
    const updated = {
      ...localBrand,
      guardrails: {
        ...localBrand.guardrails!,
        negativeKeywords: localBrand.guardrails!.negativeKeywords.filter((_, i) => i !== index)
      }
    };
    setLocalBrand(updated);
  };

  return (
    <div className="max-w-4xl mx-auto pb-32 animate-fade-in relative">
      
      {/* Top Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h2 className="text-3xl font-black text-nixtio-black tracking-tight">Brand Intelligence</h2>
          <p className="text-nixtio-gray font-medium mt-1">Configure the core logic and visual DNA of Pilot OS.</p>
        </div>
        
        {/* Risk Slider - Quick Control */}
        <div className="bg-white/60 p-4 rounded-[2rem] border border-white shadow-sm flex items-center gap-6 min-w-[280px]">
           <div className="flex flex-col">
              <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest mb-1">AI Generation Risk</span>
              <span className="text-xs font-bold text-nixtio-black">{localBrand.riskLevel} Creativity</span>
           </div>
           <div className="flex-1 px-2">
              <input 
                type="range" 
                min="0" 
                max="2" 
                step="1"
                value={localBrand.riskLevel === 'Low' ? 0 : localBrand.riskLevel === 'Medium' ? 1 : 2}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  setLocalBrand({ ...localBrand, riskLevel: val === 0 ? 'Low' : val === 1 ? 'Medium' : 'High' });
                }}
                className="w-full h-1.5 bg-slate-200 rounded-full appearance-none cursor-pointer accent-nixtio-purple" 
              />
           </div>
           <Zap size={16} className={localBrand.riskLevel === 'High' ? 'text-orange-500' : 'text-nixtio-gray/40'} />
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex bg-white/40 backdrop-blur-md p-1.5 rounded-[2.5rem] border border-white mb-10 shadow-sm">
        <TabButton active={activeTab === 'voice'} onClick={() => setActiveTab('voice')} icon={<Target size={16}/>} label="Brand Voice" />
        <TabButton active={activeTab === 'visual'} onClick={() => setActiveTab('visual')} icon={<Palette size={16}/>} label="Visual Identity" />
        <TabButton active={activeTab === 'guardrails'} onClick={() => setActiveTab('guardrails')} icon={<ShieldAlert size={16}/>} label="Constraints" />
        <TabButton active={activeTab === 'avatar'} onClick={() => setActiveTab('avatar')} icon={<Video size={16}/>} label="Avatar Setup" />
      </div>

      {/* Content Area */}
      <div className="glass-panel p-10 rounded-[3.5rem] bg-white border border-white shadow-xl min-h-[500px]">
        
        {activeTab === 'voice' && (
          <div className="space-y-10 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
               <div>
                  <label className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest mb-4 block">Tone of Voice</label>
                  <textarea 
                    value={localBrand.tone}
                    onChange={(e) => setLocalBrand({...localBrand, tone: e.target.value})}
                    placeholder="e.g. Witty, professional, minimalist but bold..."
                    className="w-full h-32 p-6 bg-nixtio-bg rounded-[2rem] border-none text-sm font-bold focus:ring-2 focus:ring-nixtio-purple transition-all resize-none"
                  />
                  <p className="mt-4 text-[10px] text-nixtio-gray font-medium leading-relaxed italic opacity-60">"This controls the personality of all generated captions and scripts."</p>
               </div>
               <div>
                  <label className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest mb-4 block">Target Audience Profile</label>
                  <textarea 
                    value={localBrand.targetAudience}
                    onChange={(e) => setLocalBrand({...localBrand, targetAudience: e.target.value})}
                    placeholder="e.g. 25-35 year old tech founders who value transparency..."
                    className="w-full h-32 p-6 bg-nixtio-bg rounded-[2rem] border-none text-sm font-bold focus:ring-2 focus:ring-nixtio-purple transition-all resize-none"
                  />
                  <p className="mt-4 text-[10px] text-nixtio-gray font-medium leading-relaxed italic opacity-60">"This ensures the AI uses vocabulary and hooks that resonate locally."</p>
               </div>
            </div>
          </div>
        )}

        {activeTab === 'visual' && (
          <div className="space-y-10 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
               <div>
                  <label className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest mb-6 block">Brand Color Palette</label>
                  <div className="flex flex-wrap gap-4">
                     {localBrand.brandColors?.map((color, idx) => (
                       <div key={idx} className="flex flex-col items-center gap-3">
                          <div className="relative group">
                             <div className="w-16 h-16 rounded-2xl shadow-lg border-4 border-white cursor-pointer transition-transform group-hover:scale-110" style={{ backgroundColor: color }}></div>
                             <button className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
                                <X size={12} />
                             </button>
                          </div>
                          <span className="text-[10px] font-black text-nixtio-black uppercase tracking-widest">{color}</span>
                       </div>
                     ))}
                     <button className="w-16 h-16 rounded-2xl border-2 border-dashed border-nixtio-black/10 flex items-center justify-center text-nixtio-gray hover:border-nixtio-purple hover:text-nixtio-purple transition-all">
                        <Plus size={20} />
                     </button>
                  </div>
               </div>
               
               <div className="space-y-8">
                  <div>
                    <label className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest mb-4 block">Asset Protection</label>
                    <div className="flex gap-4">
                       <AssetBox icon={<Plus size={20}/>} label="Upload Logo" />
                       <AssetBox icon={<Plus size={20}/>} label="Watermark" />
                    </div>
                  </div>
               </div>
            </div>
          </div>
        )}

        {activeTab === 'guardrails' && (
          <div className="space-y-10 animate-fade-in">
             <div>
                <div className="flex items-center justify-between mb-6">
                   <label className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest block">Banned Keywords & Constraints</label>
                   <div className="flex items-center gap-2 px-3 py-1 bg-red-50 text-red-500 rounded-lg text-[9px] font-black uppercase tracking-widest">
                      <ShieldAlert size={12}/> Safety Shield Active
                   </div>
                </div>
                
                <div className="flex gap-4 mb-8">
                   <input 
                    type="text" 
                    value={newKeyword}
                    onChange={(e) => setNewKeyword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addKeyword()}
                    placeholder="Add a restricted keyword..."
                    className="flex-1 p-4 bg-nixtio-bg rounded-2xl border-none text-sm font-bold focus:ring-2 focus:ring-red-500 transition-all"
                   />
                   <button onClick={addKeyword} className="px-8 bg-nixtio-black text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-cta hover:bg-nixtio-purple transition-all">
                      Add to Filter
                   </button>
                </div>

                <div className="flex flex-wrap gap-2">
                   {localBrand.guardrails?.negativeKeywords.map((kw, i) => (
                     <div key={i} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-nixtio-black/5 rounded-xl shadow-sm animate-fade-in">
                        <span className="text-xs font-bold text-nixtio-black">{kw}</span>
                        <button onClick={() => removeKeyword(i)} className="text-nixtio-gray hover:text-red-500 transition-colors"><X size={14}/></button>
                     </div>
                   ))}
                </div>
             </div>
          </div>
        )}

        {activeTab === 'avatar' && (
          <div className="space-y-10 animate-fade-in">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-6">
                   <h3 className="text-lg font-bold text-nixtio-black">Lip-Sync Training Model</h3>
                   <p className="text-sm text-nixtio-gray font-medium leading-relaxed">
                     To enable high-fidelity AI talking head generation for your CEO or Founder, upload a 30-second clear video of them speaking to the camera.
                   </p>
                   <ul className="space-y-3">
                      <li className="flex items-center gap-3 text-xs font-bold text-nixtio-gray"><CheckCircle2 size={16} className="text-emerald-500"/> Good lighting on face</li>
                      <li className="flex items-center gap-3 text-xs font-bold text-nixtio-gray"><CheckCircle2 size={16} className="text-emerald-500"/> Minimal background noise</li>
                      <li className="flex items-center gap-3 text-xs font-bold text-nixtio-gray"><CheckCircle2 size={16} className="text-emerald-500"/> 1080p+ Resolution</li>
                   </ul>
                </div>
                
                <div className="border-2 border-dashed border-nixtio-black/10 rounded-[3rem] p-12 text-center flex flex-col items-center justify-center bg-nixtio-bg/30 hover:bg-white hover:border-nixtio-purple transition-all cursor-pointer">
                   <div className="w-16 h-16 bg-white rounded-[1.5rem] shadow-sm flex items-center justify-center text-nixtio-gray mb-6">
                      <Video size={28} />
                   </div>
                   <h4 className="text-sm font-black text-nixtio-black uppercase tracking-widest">Drop Founder Clip</h4>
                   <p className="text-[9px] font-bold text-nixtio-gray mt-2 uppercase tracking-widest">MP4 or MOV • Max 200MB</p>
                </div>
             </div>
          </div>
        )}

      </div>

      {/* Floating Save Button */}
      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[110] flex flex-col items-center gap-4">
         {showSuccess && (
           <div className="bg-emerald-500 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-emerald-400 animate-bounce">
              <CheckCircle2 size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">Brand Logic Updated</span>
           </div>
         )}
         
         <button 
           onClick={handleSave}
           disabled={isSaving}
           className="px-10 py-5 bg-nixtio-black text-white rounded-full font-black text-[11px] uppercase tracking-[0.2em] shadow-2xl flex items-center gap-4 hover:scale-105 transition-all group active:scale-95 disabled:opacity-50"
         >
            {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} className="group-hover:rotate-12 transition-transform" />}
            {isSaving ? 'Synchronizing Memory...' : 'Save Brand DNA'}
         </button>
      </div>

    </div>
  );
};

const TabButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button 
    onClick={onClick}
    className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-nixtio-black text-white shadow-lg' : 'text-nixtio-gray hover:text-nixtio-black'}`}
  >
    {icon}
    <span className="hidden sm:inline">{label}</span>
  </button>
);

const AssetBox = ({ icon, label }: { icon: React.ReactNode, label: string }) => (
  <div className="w-32 h-32 rounded-3xl border-2 border-dashed border-nixtio-black/10 flex flex-col items-center justify-center text-center p-4 bg-white/40 hover:bg-white hover:border-nixtio-purple transition-all cursor-pointer group">
    <div className="text-nixtio-gray group-hover:text-nixtio-purple transition-colors mb-2">{icon}</div>
    <span className="text-[8px] font-black text-nixtio-gray uppercase tracking-widest leading-tight">{label}</span>
  </div>
);

export default Settings;
