
// @google/genai guidelines followed: Using property access for response.text and models as specified.
import React, { useState, useRef, useEffect } from 'react';
import { ContentPlanItem, Asset } from '../types';
import { 
  Play, SkipBack, SkipForward, Scissors, Type, Music, Layers, 
  Wand2, MousePointer2, Loader2, Save, Clock, Plus, Settings2, 
  Film, Volume2, Eye, EyeOff, Lock, Unlock, Sliders, Sparkles, MonitorPlay, 
  FolderSearch, ImageIcon, Video, Trash2, ChevronRight, ImagePlus,
  Grab, Info, ShieldCheck, Mic, Layout, Palette, Zap, VolumeX,
  PackageCheck, Brush, Download, Eraser, CheckCircle
} from 'lucide-react';
import { editImage, editVideo, generateVoiceover, applyBrandSignature } from '../services/contentService';

interface Props {
  plan: ContentPlanItem[];
  assets: Asset[];
  onAddAsset: (asset: Asset) => void;
}

const StudioEditor: React.FC<Props> = ({ plan, assets, onAddAsset }) => {
  const [selectedTool, setSelectedTool] = useState<'select' | 'mask' | 'gen' | 'trim' | 'audio'>('select');
  const [inpaintingPrompt, setInpaintingPrompt] = useState('');
  const [ttsText, setTtsText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<'Kore' | 'Puck' | 'Zephyr' | 'Charon'>('Zephyr');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playheadPos, setPlayheadPos] = useState(0);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeTab, setActiveTab] = useState<'Generation' | 'Inpainting' | 'Audio'>('Generation');
  const [lastMaskCoord, setLastMaskCoord] = useState<{ x: number, y: number } | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);

  // Initialize Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const mask = maskCanvasRef.current;
    if (canvas && mask) {
      const ctx = canvas.getContext('2d');
      const mctx = mask.getContext('2d');
      if (ctx && mctx) {
        ctx.fillStyle = '#05060B';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        mctx.clearRect(0, 0, mask.width, mask.height);
        
        // Load default asset if exists
        if (assets.length > 0) {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.onload = () => {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            applyBrandSignature(canvas, "ContentPilot");
          };
          img.src = assets[0].url;
        }
      }
    }
  }, [assets]);

  // Handle Drawing Logic for Masking
  const startDrawing = (e: React.MouseEvent) => {
    if (selectedTool !== 'mask') return;
    setIsDrawing(true);
    
    // Extract first coordinate for SAM 2 temporal tracking
    const mask = maskCanvasRef.current;
    if (mask) {
        const rect = mask.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (mask.width / rect.width);
        const y = (e.clientY - rect.top) * (mask.height / rect.height);
        setLastMaskCoord({ x, y });
    }
    
    draw(e);
  };

  const stopDrawing = () => setIsDrawing(false);

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing || selectedTool !== 'mask' || !maskCanvasRef.current) return;
    const canvas = maskCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    ctx.lineWidth = 40;
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'rgba(108, 114, 172, 0.6)'; // Semi-transparent Purple
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearMask = () => {
    const mask = maskCanvasRef.current;
    if (mask) {
      const mctx = mask.getContext('2d');
      mctx?.clearRect(0, 0, mask.width, mask.height);
      setLastMaskCoord(null);
    }
  };

  const handleRunInpaint = async () => {
    if (!inpaintingPrompt || isProcessing) return;
    setIsProcessing(true);
    try {
        const targetAsset = assets[0]; // Logic assumes first asset for demo
        
        if (targetAsset?.type === 'video') {
           // PRD 4.1: Call the new video inpainting endpoint with SAM 2 temporal tracking
           const result = await editVideo(
               targetAsset.url, 
               lastMaskCoord || { x: 960, y: 540 }, // Fallback to center
               inpaintingPrompt
           );
           
           if (result.url) {
              console.log("Temporal Video Inpainting Success:", result.url);
              // In real app: Update preview or add to assets
              onAddAsset({
                  id: `inpainted_${Date.now()}`,
                  url: result.url,
                  type: 'video',
                  tags: ['inpainted', inpaintingPrompt],
                  source: 'ai',
                  createdAt: Date.now()
              });
           }
        } else if (targetAsset?.type === 'image') {
           const result = await editImage(targetAsset.url, 'image/png', inpaintingPrompt);
           if (result) {
               const img = new Image();
               img.crossOrigin = "anonymous";
               img.onload = () => {
                 const ctx = canvasRef.current?.getContext('2d');
                 ctx?.drawImage(img, 0, 0, canvasRef.current!.width, canvasRef.current!.height);
                 applyBrandSignature(canvasRef.current!, "ContentPilot");
               };
               // Fix: Access the url property from the result object as editImage returns Promise<{ url: string }>
               img.src = result.url;
           }
        }
    } catch (e) { console.error("Inpainting process failed", e); }
    finally {
      setIsProcessing(false);
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 3000);
      clearMask();
    }
  };

  const handleGenerateVideo = () => {
    setIsGeneratingVideo(true);
    setTimeout(() => {
      setIsGeneratingVideo(false);
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 3000);
    }, 3000);
  };

  return (
    <div className="h-full flex flex-col gap-6 animate-fade-in overflow-hidden relative">
      {/* Toast Notification */}
      {showSuccessToast && (
        <div className="fixed top-24 right-10 z-[200] animate-fade-in">
           <div className="bg-emerald-500 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-400">
              <CheckCircle size={20} />
              <span className="text-xs font-black uppercase tracking-widest">Processing Successful</span>
           </div>
        </div>
      )}

      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0">
        
        {/* Left Column: Assets List */}
        <div className="col-span-2 flex flex-col gap-4 overflow-y-auto custom-scroll pr-1">
          <h3 className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest px-2 mb-2">Project Assets</h3>
          <div className="space-y-3">
            {assets.map(asset => (
              <div key={asset.id} className="group relative aspect-square rounded-2xl overflow-hidden bg-white border border-white hover:border-nixtio-purple transition-all cursor-pointer shadow-sm">
                {asset.type === 'video' ? <video src={asset.url} className="w-full h-full object-cover" /> : <img src={asset.url} className="w-full h-full object-cover" />}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Plus size={20} className="text-white" />
                </div>
              </div>
            ))}
            <button className="w-full aspect-square border-2 border-dashed border-nixtio-black/10 rounded-2xl flex flex-col items-center justify-center text-nixtio-gray hover:border-nixtio-purple hover:text-nixtio-purple transition-all bg-white/40">
              <Plus size={24} />
              <span className="text-[8px] font-black uppercase mt-2">New Asset</span>
            </button>
          </div>
        </div>

        {/* Center Column: Video Player / Canvas */}
        <div className="col-span-7 flex flex-col gap-6 h-full min-h-0">
          <div className="flex-1 bg-nixtio-black rounded-[3rem] border border-white/10 overflow-hidden relative shadow-2xl flex flex-col group/canvas">
            
            {/* Tool Overlay */}
            <div className="absolute top-6 left-6 flex gap-2 z-20">
              <button 
                onClick={() => setSelectedTool('select')} 
                className={`p-3 rounded-xl transition-all ${selectedTool === 'select' ? 'bg-white text-nixtio-black shadow-lg' : 'bg-nixtio-black/40 text-white/60 hover:text-white backdrop-blur-md'}`}
              >
                <MousePointer2 size={18} />
              </button>
              <button 
                onClick={() => setSelectedTool('mask')} 
                className={`p-3 rounded-xl transition-all ${selectedTool === 'mask' ? 'bg-nixtio-purple text-white shadow-lg' : 'bg-nixtio-black/40 text-white/60 hover:text-white backdrop-blur-md'}`}
              >
                <Brush size={18} />
              </button>
              {selectedTool === 'mask' && (
                <button onClick={clearMask} className="p-3 rounded-xl bg-red-500/80 text-white backdrop-blur-md hover:bg-red-600 transition-all">
                  <Eraser size={18} />
                </button>
              )}
            </div>

            {/* Canvas Stack */}
            <div className="flex-1 relative cursor-crosshair flex items-center justify-center bg-slate-950">
              <canvas 
                ref={canvasRef} 
                width={1920} 
                height={1080}
                className="max-w-full max-h-full object-contain relative z-0"
              />
              <canvas 
                ref={maskCanvasRef}
                width={1920} 
                height={1080}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                className={`absolute inset-0 w-full h-full object-contain z-10 ${selectedTool === 'mask' ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
              />
            </div>

            {/* Inpainting Prompt Overlay */}
            {selectedTool === 'mask' && (
              <div className="absolute bottom-6 left-6 right-6 z-20 animate-fade-in">
                <div className="p-4 bg-nixtio-black/80 backdrop-blur-xl border border-white/10 rounded-3xl flex gap-4 items-center">
                  <Wand2 size={20} className="text-nixtio-purple shrink-0" />
                  <input 
                    type="text" 
                    placeholder="Describe what to change in the masked area..."
                    className="flex-1 bg-transparent text-xs font-bold text-white outline-none"
                    value={inpaintingPrompt}
                    onChange={(e) => setInpaintingPrompt(e.target.value)}
                  />
                  <button 
                    onClick={handleRunInpaint}
                    disabled={!inpaintingPrompt || isProcessing}
                    className="px-6 py-2.5 bg-nixtio-purple text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-nixtio-soft transition-all disabled:opacity-50 flex items-center gap-2"
                  >
                    {isProcessing ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    Inpaint
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Timeline Placeholder */}
          <div className="h-32 bg-white/60 backdrop-blur-xl border border-white rounded-[2.5rem] flex flex-col p-4 shadow-sm">
             <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-4">
                   <button onClick={() => setIsPlaying(!isPlaying)} className="p-2 bg-nixtio-black text-white rounded-xl hover:bg-nixtio-purple transition-colors">
                      {isPlaying ? <VolumeX size={16}/> : <Play size={16} fill="currentColor" />}
                   </button>
                   <span className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest">00:00:12 / 00:01:00</span>
                </div>
                <div className="flex gap-2">
                   <button className="p-2 text-nixtio-gray hover:text-nixtio-black"><Scissors size={16}/></button>
                   <button className="p-2 text-nixtio-gray hover:text-nixtio-black"><Layers size={16}/></button>
                </div>
             </div>
             <div className="flex-1 bg-slate-100 rounded-xl relative overflow-hidden flex flex-col gap-1 p-1">
                <div className="absolute top-0 bottom-0 w-0.5 bg-nixtio-purple z-10 transition-all duration-100" style={{ left: '25%' }}></div>
                <div className="flex-1 bg-nixtio-purple/10 rounded-lg border border-nixtio-purple/20 flex items-center px-4 overflow-hidden">
                   <div className="flex gap-1">
                      {Array.from({length: 20}).map((_, i) => <div key={i} className="w-1 h-3 bg-nixtio-purple/30 rounded-full"></div>)}
                   </div>
                </div>
                <div className="flex-1 bg-emerald-500/10 rounded-lg border border-emerald-500/20"></div>
             </div>
          </div>
        </div>

        {/* Right Column: Controls Panel */}
        <div className="col-span-3 flex flex-col gap-6">
          <div className="glass-panel p-6 rounded-[2.5rem] bg-white border border-white flex flex-col h-full shadow-sm">
            
            {/* Tabs */}
            <div className="flex bg-nixtio-bg p-1 rounded-2xl mb-8">
              {(['Generation', 'Inpainting', 'Audio'] as const).map(tab => (
                <button 
                  key={tab} 
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-white text-nixtio-black shadow-sm' : 'text-nixtio-gray hover:text-nixtio-black'}`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto custom-scroll space-y-8 pr-1">
              {activeTab === 'Generation' && (
                <div className="space-y-6 animate-fade-in">
                  <div>
                    <label className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest mb-3 block">Scene Description</label>
                    <textarea 
                      className="w-full bg-nixtio-bg border-none rounded-2xl p-4 text-[11px] font-bold h-32 resize-none focus:ring-2 focus:ring-nixtio-purple transition-all"
                      placeholder="Describe the cinematic scene..."
                    />
                  </div>
                  <button 
                    onClick={handleGenerateVideo}
                    disabled={isGeneratingVideo}
                    className="w-full py-5 bg-nixtio-black text-white rounded-3xl text-[11px] font-black uppercase tracking-widest shadow-cta flex items-center justify-center gap-3 hover:scale-[1.02] transition-all disabled:opacity-50"
                  >
                    {isGeneratingVideo ? <Loader2 size={18} className="animate-spin" /> : <Film size={18} />}
                    {isGeneratingVideo ? 'Rendering...' : 'Generate Video'}
                  </button>
                </div>
              )}

              {activeTab === 'Inpainting' && (
                <div className="space-y-6 animate-fade-in text-center py-10">
                  <div className="w-16 h-16 bg-nixtio-purple/10 rounded-2xl flex items-center justify-center text-nixtio-purple mx-auto mb-4">
                    <Brush size={28} />
                  </div>
                  <h4 className="text-sm font-bold text-nixtio-black">Manual Masking Mode</h4>
                  <p className="text-[11px] text-nixtio-gray font-medium leading-relaxed">Use the brush tool on the canvas to highlight specific areas. SAM 2 will automatically track your mask across all video frames to ensure consistency.</p>
                  <button 
                    onClick={() => setSelectedTool('mask')}
                    className="w-full py-4 bg-nixtio-purple text-white rounded-2xl text-[10px] font-black uppercase tracking-widest"
                  >
                    Activate Brush
                  </button>
                </div>
              )}

              {activeTab === 'Audio' && (
                <div className="space-y-6 animate-fade-in">
                  <div>
                    <label className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest mb-4 block">Voice Selection</label>
                    <div className="grid grid-cols-2 gap-2">
                       {['Zephyr', 'Kore', 'Puck', 'Charon'].map((v: any) => (
                         <button key={v} onClick={() => setSelectedVoice(v)} className={`py-3 rounded-xl text-[9px] font-black uppercase tracking-widest border transition-all ${selectedVoice === v ? 'bg-nixtio-black text-white border-nixtio-black shadow-sm' : 'bg-white border-nixtio-black/5 text-nixtio-gray hover:bg-nixtio-bg'}`}>{v}</button>
                       ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest mb-3 block">Script Text</label>
                    <textarea 
                      className="w-full bg-nixtio-bg border-none rounded-2xl p-4 text-[11px] font-bold h-32 resize-none focus:ring-2 focus:ring-nixtio-purple transition-all"
                      placeholder="Enter script for voiceover..."
                      value={ttsText}
                      onChange={e => setTtsText(e.target.value)}
                    />
                  </div>
                  <button 
                    onClick={() => generateVoiceover(ttsText, selectedVoice)}
                    className="w-full py-5 bg-nixtio-black text-white rounded-3xl text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-3"
                  >
                    <Mic size={18} /> Render Voice
                  </button>
                </div>
              )}
            </div>

            <div className="mt-8 pt-8 border-t border-nixtio-bg flex flex-col gap-3">
              <button className="w-full py-4 rounded-2xl border-2 border-nixtio-black text-nixtio-black font-black text-[10px] uppercase tracking-widest hover:bg-nixtio-black hover:text-white transition-all flex items-center justify-center gap-2">
                 <Download size={14}/> Save Progress
              </button>
              <button className="w-full py-4 rounded-2xl bg-emerald-500 text-white font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 hover:scale-105 transition-all">
                 <PackageCheck size={16}/> Neural Multiplex
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default StudioEditor;
