
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { BrainCircuit, Mail, ArrowRight, Loader2, Lock, ShieldCheck } from 'lucide-react';

const Login: React.FC = () => {
  const { loginWithEmail, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    try {
      await loginWithEmail(email, password);
    } catch (err) {
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-50 relative overflow-hidden">
      
      {/* Background Shapes */}
      <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-purple-100 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-blue-100 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="w-full max-w-md bg-white p-8 md:p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-100 relative z-10">
        <div className="flex flex-col items-center mb-10">
            <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center mb-4 shadow-xl">
                <BrainCircuit className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2 tracking-tight">ContentPilot</h1>
            <p className="text-slate-500 text-center text-sm font-medium">Enterprise Social Operating System</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-xl text-xs font-bold flex items-center gap-2 border border-red-100 animate-pulse">
            <ShieldCheck size={14} className="rotate-180" />
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-900 uppercase tracking-wider ml-1">Work Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@company.com"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-slate-900 focus:ring-2 focus:ring-black focus:bg-white outline-none transition-all text-sm font-medium"
                  />
                </div>
            </div>

            <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-900 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-slate-900 focus:ring-2 focus:ring-black focus:bg-white outline-none transition-all text-sm font-medium"
                  />
                </div>
            </div>

            <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-black text-white font-black py-5 px-4 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl hover:bg-slate-800 active:scale-[0.98] uppercase tracking-widest text-xs"
            >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Sign In <ArrowRight className="w-4 h-4" /></>}
            </button>
        </form>

        <div className="mt-8 pt-8 border-t border-slate-100 text-center">
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                Protected by Enterprise JWT Auth
             </p>
        </div>
      </div>
      
      <div className="mt-8 text-center">
            <p className="text-[10px] text-slate-400 font-medium">
                © 2024 ContentPilot Inc. Secure Environment v2.1
            </p>
      </div>
    </div>
  );
};

export default Login;
