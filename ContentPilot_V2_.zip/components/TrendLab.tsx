
import React from 'react';
import { Trend } from '../types';
import { Search, Flame, TrendingUp, ExternalLink, Zap, RefreshCcw, Music, Sparkles, Video, Instagram, Youtube, Globe, Telescope } from 'lucide-react';

interface Props {
  trends: Trend[];
  onRefresh: () => void;
  isRefreshing?: boolean;
  onUseTemplate?: (trend: Trend) => void;
}

const TrendLab: React.FC<Props> = ({ trends, onRefresh, isRefreshing, onUseTemplate }) => {
  const getPlatformIcon = (platform?: string) => {
    switch(platform) {
      case 'TikTok': return <Video size={14}/>;
      case 'Instagram': return <Instagram size={14}/>;
      case 'YouTube': return <Youtube size={14}/>;
      default: return <Globe size={14}/>;
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-nixtio-black mb-1">Viral Patterns</h2>
          <p className="text-nixtio-gray font-medium text-sm">Real-time trends detected across TikTok & Reels.</p>
        </div>
        <button onClick={onRefresh} disabled={isRefreshing} className={`flex items-center gap-2 px-6 py-4 rounded-full bg-nixtio-black text-white text-[11px] font-bold uppercase tracking-widest shadow-cta ${isRefreshing ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 transition-all'}`}>
          {isRefreshing ? <RefreshCcw size={16} className="animate-spin" /> : <Search size={16} />}
          {isRefreshing ? 'Scanning...' : 'Scan Horizon'}
        </button>
      </div>

      {trends.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-40 text-center glass-panel rounded-[3rem] bg-white/40 border-dashed border-nixtio-black/10">
           <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-nixtio-purple/20 mb-8 border border-white shadow-sm">
              <Telescope size={40} />
           </div>
           <h3 className="text-xl font-black text-nixtio-black mb-2">Initialize your Viral Engine.</h3>
           <p className="text-sm text-nixtio-gray max-w-sm mb-10 font-medium leading-relaxed">The social horizon is empty. Scan for trending patterns, viral audio, and content hooks that are moving the needle right now.</p>
           
           <button onClick={onRefresh} disabled={isRefreshing} className="group relative px-10 py-5 bg-nixtio-purple text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl transition-all hover:scale-105 overflow-hidden">
              <span className="relative z-10 flex items-center gap-3">
                <Sparkles size={16} className="group-hover:rotate-12 transition-transform" />
                Run Horizon Scan
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
           </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trends.map((trend) => (
            <div key={trend.id} className="glass-panel p-8 rounded-[2.5rem] bg-white/40 hover:bg-white/60 transition-all flex flex-col relative group">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase text-nixtio-gray">
                   {getPlatformIcon(trend.platform)} {trend.platform}
                </div>
                <div className="flex items-center gap-1">
                   <span className="text-lg font-bold text-nixtio-black">{trend.relevanceScore}%</span>
                   <TrendingUp size={14} className="text-emerald-500" />
                </div>
              </div>

              <h3 className="text-lg font-bold text-nixtio-black mb-3 leading-snug">{trend.title}</h3>
              <p className="text-[13px] text-nixtio-gray leading-relaxed mb-6 line-clamp-3 font-medium">{trend.description}</p>

              <div className="mt-auto space-y-4">
                <div className="p-4 bg-white/40 rounded-2xl border border-white/80">
                  <span className="text-[9px] font-bold text-nixtio-purple uppercase tracking-widest block mb-1">Blueprint</span>
                  <p className="text-[11px] text-nixtio-black font-semibold italic line-clamp-2">"{trend.suggestedTemplate}"</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => onUseTemplate?.(trend)} className="flex-1 py-3.5 rounded-2xl bg-nixtio-black text-white font-bold text-[10px] uppercase tracking-widest hover:bg-nixtio-purple transition-all">Use Trend</button>
                  <a href={trend.sourceUrl} target="_blank" rel="noreferrer" className="p-3.5 rounded-2xl bg-white border border-nixtio-black/5 text-nixtio-gray hover:text-nixtio-black transition-all"><ExternalLink size={18} /></a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TrendLab;
