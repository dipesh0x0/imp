
import React, { useState, useRef } from 'react';
import { BrandInfo, Platform, Asset } from '../types';
import { Globe, Instagram, ArrowLeft, Briefcase, Loader2, Check, X, UserCircle, Sparkles } from 'lucide-react';

interface Props {
  onSubmit: (brand: BrandInfo, initialAssets?: Asset[]) => void;
  isLoading: boolean;
  onBack?: () => void;
}

const BrandForm: React.FC<Props> = ({ onSubmit, isLoading, onBack }) => {
  const [url, setUrl] = useState('');
  const [uploadedAssets, setUploadedAssets] = useState<Asset[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [brand, setBrand] = useState<BrandInfo>({
    name: '',
    description: '',
    industry: '',
    tone: 'Modern',
    targetAudience: '',
    platforms: [Platform.Instagram, Platform.TikTok]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
        ...brand,
        name: brand.name || url.replace('https://', '').split('.')[0],
        description: brand.description || `Strategy for ${url}`
    }, uploadedAssets);
  };

  return (
    <div className="max-w-xl mx-auto animate-fade-in py-10">
      <div className="space-y-10">
        <section>
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold tracking-tight text-nixtio-black mb-1">Brand Profile</h2>
              <p className="text-sm text-nixtio-gray font-medium">Link your presence to customize the strategy.</p>
            </div>
            {onBack && (
              <button onClick={onBack} className="p-3 rounded-full bg-white shadow-sm text-nixtio-gray hover:text-nixtio-black transition-all">
                <ArrowLeft size={18} />
              </button>
            )}
          </div>
          
          <div className="space-y-4">
              <div className="bg-white rounded-3xl p-5 shadow-sm border border-nixtio-black/5 flex items-center">
                  <Globe size={18} className="text-nixtio-purple mr-4" />
                  <input type="url" placeholder="https://apple.com" className="w-full bg-transparent text-sm font-bold text-nixtio-black focus:outline-none" value={url} onChange={e => setUrl(e.target.value)} />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-nixtio-black/5 flex items-center">
                    <Briefcase size={16} className="text-nixtio-gray mr-3" />
                    <input placeholder="Industry (e.g. Sustainable Fashion)" className="w-full bg-transparent text-xs font-bold text-nixtio-black focus:outline-none" value={brand.industry} onChange={e => setBrand({...brand, industry: e.target.value})} />
                </div>
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-nixtio-black/5 flex items-center">
                    <UserCircle size={16} className="text-nixtio-gray mr-3" />
                    <input placeholder="Audience (e.g. Tech-savvy Creators)" className="w-full bg-transparent text-xs font-bold text-nixtio-black focus:outline-none" value={brand.targetAudience} onChange={e => setBrand({...brand, targetAudience: e.target.value})} />
                </div>
              </div>
          </div>
        </section>

        <section className="pt-10 border-t border-nixtio-black/5">
          <h2 className="text-lg font-bold text-nixtio-black mb-6">Upload Assets</h2>
          <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-nixtio-black/10 rounded-[2.5rem] p-12 text-center hover:border-nixtio-purple transition-all cursor-pointer bg-white/40">
            <input type="file" ref={fileInputRef} className="hidden" multiple accept="image/*,video/*" onChange={() => {}} />
            <div className="flex justify-center mb-4">
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-nixtio-gray">
                {isUploading ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} />}
              </div>
            </div>
            <p className="text-sm text-nixtio-black font-bold">Drop Logos or Clips</p>
            <p className="text-[10px] text-nixtio-gray mt-2 uppercase font-black tracking-widest">Supports PNG, JPG, MP4</p>
          </div>
        </section>

        <button onClick={handleSubmit} disabled={isLoading || !url} className="w-full py-5 bg-nixtio-black text-white text-[11px] font-bold rounded-3xl shadow-cta flex items-center justify-center gap-3 hover:scale-[1.02] transition-all disabled:opacity-30 uppercase tracking-widest">
            {isLoading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
            Build Strategy
        </button>
      </div>
    </div>
  );
};

export default BrandForm;
