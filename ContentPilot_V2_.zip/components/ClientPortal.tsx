
import React, { useState } from 'react';
import { ContentPlanItem } from '../types';
import { Share, CheckCircle, XCircle, MessageSquare, Link, Copy, ArrowRight, ShieldCheck, UserCircle } from 'lucide-react';

interface Props {
  plan: ContentPlanItem[];
  onReview: (day: number, status: 'completed' | 'rejected', feedback?: string) => void;
}

const ClientPortal: React.FC<Props> = ({ plan, onReview }) => {
  const [selectedItem, setSelectedItem] = useState<ContentPlanItem | null>(null);
  const [feedback, setFeedback] = useState('');
  const [magicLink, setMagicLink] = useState('');

  const generateLink = () => {
    setMagicLink(`https://contentpilot.app/portal/magic-${Math.random().toString(36).substr(2, 9)}`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 animate-fade-in">
      <div className="lg:col-span-8 space-y-8">
        <div className="flex items-center justify-between">
           <div>
              <h2 className="text-2xl font-black text-nixtio-black">Agency Client Portal</h2>
              <p className="text-nixtio-gray font-medium text-sm">Review drafts and approve for deployment.</p>
           </div>
           <button onClick={generateLink} className="flex items-center gap-2 bg-nixtio-black text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-cta">
              <Link size={14}/> {magicLink ? 'Refresh Magic Link' : 'Generate Magic Link'}
           </button>
        </div>

        {magicLink && (
          <div className="p-6 bg-nixtio-purple/5 border border-nixtio-purple/20 rounded-[32px] flex items-center justify-between animate-fade-in">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-nixtio-purple/10 text-nixtio-purple flex items-center justify-center"><ShieldCheck size={20}/></div>
                <p className="text-[11px] font-black text-nixtio-purple uppercase tracking-widest truncate max-w-sm">{magicLink}</p>
             </div>
             <button onClick={() => navigator.clipboard.writeText(magicLink)} className="p-3 bg-white rounded-xl text-nixtio-gray hover:text-nixtio-black shadow-sm transition-all"><Copy size={16}/></button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {plan.filter(i => i.status === 'completed' || i.status === 'pending').map(item => (
            <div key={item.day} onClick={() => setSelectedItem(item)} className={`glass-panel p-6 rounded-[32px] border-2 transition-all cursor-pointer ${selectedItem?.day === item.day ? 'border-nixtio-black shadow-xl bg-white' : 'border-transparent hover:bg-white/60'}`}>
              <div className="flex justify-between items-start mb-4">
                 <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest">Day {item.day}</span>
                 <div className={`px-3 py-1 rounded-lg text-[8px] font-black uppercase ${item.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 'bg-nixtio-bg text-nixtio-gray'}`}>{item.status}</div>
              </div>
              <h3 className="text-sm font-black text-nixtio-black mb-4 truncate">{item.title}</h3>
              <div className="aspect-video bg-nixtio-bg rounded-2xl overflow-hidden mb-4">
                 {item.assetUrl && <img src={item.assetUrl} className="w-full h-full object-cover" />}
              </div>
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <UserCircle size={14} className="text-nixtio-gray" />
                    <span className="text-[10px] font-bold text-nixtio-gray uppercase tracking-widest">Awaiting Brand Approval</span>
                 </div>
                 <ArrowRight size={14} className="text-nixtio-purple" />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="lg:col-span-4 space-y-6">
        {selectedItem ? (
          <div className="glass-panel p-8 rounded-[40px] bg-white sticky top-10 shadow-2xl animate-fade-in">
             <h3 className="text-lg font-black text-nixtio-black mb-6">Review Content</h3>
             <div className="space-y-6 mb-8">
                <div>
                   <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest block mb-2">Caption Copy</span>
                   <p className="text-xs font-medium text-nixtio-black leading-relaxed p-4 bg-nixtio-bg rounded-2xl">"{selectedItem.caption}"</p>
                </div>
                <div>
                   <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest block mb-2">Strategic Reason</span>
                   <p className="text-xs font-medium text-nixtio-gray italic">"{selectedItem.reasoning}"</p>
                </div>
             </div>

             <div className="space-y-4">
                <textarea 
                  className="w-full bg-nixtio-bg border-none rounded-2xl p-4 text-[11px] h-24 font-medium focus:ring-2 focus:ring-nixtio-purple transition-all" 
                  placeholder="Internal client feedback (optional)..."
                  value={feedback}
                  onChange={e => setFeedback(e.target.value)}
                />
                <div className="grid grid-cols-2 gap-4">
                   <button onClick={() => { onReview(selectedItem.day, 'rejected', feedback); setSelectedItem(null); setFeedback(''); }} className="py-4 rounded-2xl border-2 border-red-500/10 text-red-500 font-black text-[10px] uppercase tracking-widest hover:bg-red-50 transition-all flex items-center justify-center gap-2">
                      <XCircle size={14}/> Reject
                   </button>
                   <button onClick={() => { onReview(selectedItem.day, 'completed', feedback); setSelectedItem(null); setFeedback(''); }} className="py-4 rounded-2xl bg-emerald-500 text-white font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center gap-2">
                      <CheckCircle size={14}/> Approve
                   </button>
                </div>
             </div>
          </div>
        ) : (
          <div className="glass-panel p-8 rounded-[40px] border-dashed border-nixtio-black/5 flex flex-col items-center justify-center text-center gap-4 py-20">
             <MessageSquare size={32} className="text-nixtio-gray/20" />
             <p className="text-xs font-black text-nixtio-gray/40 uppercase tracking-widest">Select a draft to initiate review</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientPortal;
