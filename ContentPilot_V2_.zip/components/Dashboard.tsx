
// @google/genai guidelines followed: Using property access for response.text and models as specified.
import React, { useState, useEffect } from 'react';
import { ContentPlanItem, GenerationState, BrandInfo } from '../types';
import { 
  Film, Trophy, Ban, Sparkles, 
  Rocket, Video, Flame, BrainCircuit, 
  TrendingUp, Activity, Zap, CheckCircle2,
  History, ChevronRight, LayoutGrid, List, MessageSquareWarning,
  Globe
} from 'lucide-react';
import { predictPerformance, runPostMortem, geoAdaptContent, checkCompetitiveCollision, evaluateVisualCohesion, runHookForensics, interceptTrendJack } from '../services/contentService';
import { useAuth } from '../context/AuthContext';

interface Props {
  state: GenerationState;
  brandInfo: BrandInfo;
  updatePlanItem: (day: number, updates: Partial<ContentPlanItem>) => void;
  onReset: () => void;
  onUpdateBrand?: (brand: BrandInfo) => void;
  onUseTemplate?: () => void;
}

interface DashboardStats {
  totalPosts: string;
  avgEngagement: string;
  gpuSaved: string;
  totalPostsTrend: string;
  avgEngagementTrend: string;
  gpuSavedTrend: string;
}

interface RecentActivity {
  id: string;
  label: string;
  status: 'Completed' | 'Processing' | 'Failed';
  time: string;
}

const Dashboard: React.FC<Props> = ({ state, brandInfo, updatePlanItem, onUpdateBrand, onUseTemplate }) => {
  const { authenticatedFetch } = useAuth();
  const [selectedDay, setSelectedDay] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [visualCohesion, setVisualCohesion] = useState<{score: number, feedback: string, suggestedPalette: string[]} | null>(null);
  const [hookForensics, setHookForensics] = useState<any>(null);
  const [trendAlert, setTrendAlert] = useState<any>(null);
  const [collisionReport, setCollisionReport] = useState<{isCollision: boolean, reason: string} | null>(null);
  const [selectedGeo, setSelectedGeo] = useState<string>('');
  const [wisdomNote, setWisdomNote] = useState<string | null>(null);

  // New states for real API data
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [activities, setActivities] = useState<RecentActivity[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);

  const currentItem = state.plan[selectedDay];

  // Fetch Dashboard Data from API
  useEffect(() => {
    const fetchDashboardData = async () => {
      setIsLoadingData(true);
      try {
        const [statsRes, activityRes] = await Promise.all([
          authenticatedFetch('/api/dashboard/stats'),
          authenticatedFetch('/api/generations/recent')
        ]);

        if (statsRes.ok) {
          const statsData = await statsRes.json();
          setStats(statsData);
        } else {
          // Fallback if endpoint doesn't exist yet in mock
          setStats({
            totalPosts: "124",
            avgEngagement: "4.8%",
            gpuSaved: "12h",
            totalPostsTrend: "+12 this month",
            avgEngagementTrend: "+0.5% vs last week",
            gpuSavedTrend: "Equivalent to 2 staff days"
          });
        }

        if (activityRes.ok) {
          const activityData = await activityRes.json();
          setActivities(activityData);
        } else {
          // Fallback for activity
          setActivities([
            { id: '1', label: "Video Generation", status: "Completed", time: "2m ago" },
            { id: '2', label: "Strategy Tuning", status: "Processing", time: "5m ago" },
            { id: '3', label: "Instagram Sync", status: "Failed", time: "15m ago" },
            { id: '4', label: "Voiceover Render", status: "Completed", time: "1h ago" }
          ]);
        }
      } catch (err) {
        console.error("Dashboard Fetch Error", err);
      } finally {
        setIsLoadingData(false);
      }
    };

    fetchDashboardData();
  }, []);

  useEffect(() => {
    if (state.plan.length > 0 && !visualCohesion && !isProcessing) {
      evaluateVisualCohesion(state.plan, brandInfo).then(setVisualCohesion);
    }
  }, [state.plan]);

  useEffect(() => {
    if (Math.random() > 0.7) {
      interceptTrendJack(brandInfo).then(alert => {
        if (alert?.trendFound) setTrendAlert(alert);
      });
    }
  }, [selectedDay]);

  useEffect(() => {
    if (currentItem) {
      if (!currentItem.predictionScore) {
        predictPerformance(currentItem, brandInfo, state.trends).then(score => {
          updatePlanItem(currentItem.day, { predictionScore: score });
        });
      }
      checkCompetitiveCollision(currentItem, brandInfo).then(setCollisionReport);
      runHookForensics(currentItem).then(setHookForensics);
      setWisdomNote(null);
    }
  }, [selectedDay, currentItem?.day]);

  const handleApplyTrendJack = () => {
    if (!trendAlert || !currentItem) return;
    updatePlanItem(currentItem.day, { 
      visualHook: trendAlert.hook, 
      reasoning: `HOT-SWAP: ${trendAlert.justification}` 
    });
    setTrendAlert(null);
  };

  const handleRecursiveFeedback = async (success: boolean) => {
    if (!currentItem || !onUpdateBrand) return;
    setIsProcessing(true);
    try {
      updatePlanItem(currentItem.day, { performance: success ? 'win' : 'flop' });
      const wisdom = await runPostMortem(currentItem, success);
      setWisdomNote(wisdom);
      const currentMemory = brandInfo.memory || { winningPromptDNA: [], flopConstraints: [], industryInsights: [] };
      const updatedMemory = {
        ...currentMemory,
        winningPromptDNA: success ? [...currentMemory.winningPromptDNA, currentItem.prompt].slice(-10) : currentMemory.winningPromptDNA,
        flopConstraints: !success ? [...currentMemory.flopConstraints, currentItem.contentPillar].slice(-10) : currentMemory.flopConstraints,
        industryInsights: [...currentMemory.industryInsights, wisdom].slice(-5)
      };
      onUpdateBrand({ ...brandInfo, memory: updatedMemory });
    } catch (e) { console.error(e); } finally { setIsProcessing(false); }
  };

  if (!currentItem) return <div className="text-center py-20 font-bold text-nixtio-gray">Initializing OS...</div>;

  return (
    <div className="flex flex-col gap-8 h-full">
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          icon={<CheckCircle2 size={20} className="text-nixtio-purple"/>} 
          label="Total Posts" 
          value={stats?.totalPosts || "0"} 
          trend={stats?.totalPostsTrend || "Calculating..."} 
        />
        <StatCard 
          icon={<TrendingUp size={20} className="text-emerald-500"/>} 
          label="Avg Engagement" 
          value={stats?.avgEngagement || "0%"} 
          trend={stats?.avgEngagementTrend || "Analyzing..."} 
        />
        <StatCard 
          icon={<Zap size={20} className="text-orange-500"/>} 
          label="GPU Time Saved" 
          value={stats?.gpuSaved || "0h"} 
          trend={stats?.gpuSavedTrend || "Synthesizing..."} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1 min-h-0">
        {/* Left Column: Plan Selection */}
        <div className="lg:col-span-3 flex flex-col gap-6 overflow-y-auto pr-2 custom-scroll">
          <div className="flex items-center justify-between mb-2 px-2">
              <div className="flex bg-white/60 p-1 rounded-xl border border-white">
                  <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-nixtio-black text-white shadow-sm' : 'text-nixtio-gray'}`}><List size={14}/></button>
                  <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-nixtio-black text-white shadow-sm' : 'text-nixtio-gray'}`}><LayoutGrid size={14}/></button>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 bg-nixtio-purple/10 rounded-lg">
                  <div className="w-1.5 h-1.5 bg-nixtio-purple rounded-full animate-pulse"></div>
                  <span className="text-[8px] font-black text-nixtio-purple uppercase tracking-widest">Live Sync</span>
              </div>
          </div>

          <div className="space-y-3">
            {viewMode === 'list' ? (
              state.plan.map((item, idx) => (
                <div key={item.day} onClick={() => setSelectedDay(idx)} className={`p-5 rounded-[2rem] border transition-all cursor-pointer relative overflow-hidden ${selectedDay === idx ? 'bg-white border-nixtio-black shadow-lg scale-[1.02]' : 'bg-white/40 border-transparent hover:bg-white/60'}`}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[9px] font-black uppercase text-nixtio-gray">Day {item.day}</span>
                    <div className="flex items-center gap-2">
                      {item.performance === 'win' && <Trophy size={12} className="text-emerald-500" />}
                      {item.predictionScore && (
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[7px] font-black text-white ${item.predictionScore > 75 ? 'bg-emerald-500' : 'bg-nixtio-purple'}`}>
                          {item.predictionScore}
                        </div>
                      )}
                    </div>
                  </div>
                  <h4 className="text-[11px] font-bold leading-tight truncate text-nixtio-black">{item.title}</h4>
                </div>
              ))
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {state.plan.map((item, idx) => (
                  <div key={item.day} onClick={() => setSelectedDay(idx)} className={`aspect-square rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${selectedDay === idx ? 'border-nixtio-black shadow-lg scale-[1.02]' : 'border-transparent opacity-60'}`}>
                      {item.assetUrl ? <img src={item.assetUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-slate-200 flex items-center justify-center text-nixtio-gray/20"><Film size={20}/></div>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {visualCohesion && (
            <div className="p-6 bg-white/60 border border-white rounded-[2.5rem] shadow-sm mt-4">
               <div className="flex items-center justify-between mb-4">
                  <span className="text-[9px] font-black text-nixtio-purple uppercase tracking-widest">Aesthetic Score</span>
                  <span className="text-xs font-black text-nixtio-black">{visualCohesion.score}%</span>
               </div>
               <div className="h-1.5 w-full bg-slate-100 rounded-full mb-4 overflow-hidden">
                  <div className="h-full bg-nixtio-purple rounded-full transition-all duration-1000" style={{ width: `${visualCohesion.score}%` }}></div>
               </div>
               <p className="text-[10px] text-nixtio-gray font-medium leading-tight mb-4 italic">"{visualCohesion.feedback}"</p>
               <div className="flex gap-2">
                  {visualCohesion.suggestedPalette.map(color => (
                    <div key={color} className="w-4 h-4 rounded-full border border-black/5" style={{ backgroundColor: color }}></div>
                  ))}
               </div>
            </div>
          )}
        </div>

        {/* Center Column: Detailed Work Area */}
        <div className="lg:col-span-6 flex flex-col h-full overflow-hidden">
          <div className="glass-panel rounded-[3rem] p-8 h-full flex flex-col shadow-xl bg-white overflow-y-auto custom-scroll">
            {trendAlert && (
               <div className="mb-6 p-6 bg-nixtio-black text-white rounded-[2.5rem] animate-bounce flex items-center gap-5 shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform"><Flame size={64} fill="white"/></div>
                  <div className="w-12 h-12 bg-nixtio-purple rounded-2xl flex items-center justify-center shrink-0"><Zap size={24}/></div>
                  <div className="flex-1">
                    <h4 className="text-[10px] font-black text-nixtio-soft uppercase tracking-widest mb-1">Trend Intercept</h4>
                    <p className="text-[11px] font-bold leading-tight mb-3">"{trendAlert.justification}"</p>
                    <button onClick={handleApplyTrendJack} className="px-4 py-2 bg-white text-nixtio-black rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-nixtio-soft transition-all">Apply Strategy</button>
                  </div>
               </div>
            )}

            <div className="flex items-center justify-between mb-8">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-nixtio-black flex items-center justify-center text-white shadow-sm"><Film size={18}/></div>
                  <div>
                      <h3 className="text-sm font-black text-nixtio-black">{currentItem.title}</h3>
                      <p className="text-[9px] font-bold text-nixtio-gray uppercase tracking-widest mt-1">{currentItem.platform}</p>
                  </div>
               </div>
            </div>

            <div className="aspect-[9/16] max-h-[480px] mx-auto bg-slate-950 rounded-[2.5rem] relative overflow-hidden mb-8 shadow-2xl border-4 border-white group">
              {currentItem.assetUrl ? (
                  <img src={currentItem.assetUrl} className="w-full h-full object-cover" /> 
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white/40 gap-4">
                  <Video size={48} className="animate-pulse" />
                  <p className="text-[10px] font-black uppercase tracking-widest">Asset not rendered</p>
                </div>
              )}
              
              <div className="absolute bottom-6 left-6 right-6">
                {hookForensics && (
                  <div className="grid grid-cols-4 gap-2 px-4 py-3 bg-black/60 backdrop-blur-md rounded-2xl border border-white/10">
                     <ForensicMeter label="Hook" value={hookForensics.curiosity} />
                     <ForensicMeter label="Urgency" value={hookForensics.urgency} />
                     <ForensicMeter label="Proof" value={hookForensics.socialProof} />
                     <ForensicMeter label="Value" value={hookForensics.utility} />
                  </div>
                )}
              </div>
            </div>

            {wisdomNote && (
              <div className="mb-8 p-6 bg-nixtio-purple/5 border border-nixtio-purple/10 rounded-3xl animate-fade-in flex items-center gap-4">
                 <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-nixtio-purple shadow-sm shrink-0"><BrainCircuit size={18}/></div>
                 <p className="text-[11px] font-bold text-nixtio-purple leading-tight italic">"{wisdomNote}"</p>
              </div>
            )}

            <div className="mt-auto grid grid-cols-1 sm:grid-cols-2 gap-4">
               <div className="p-5 bg-nixtio-bg/50 rounded-3xl border border-white flex items-center gap-4">
                  {/* Fixed missing Globe icon by adding it to imports */}
                  <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-nixtio-purple shadow-sm"><Globe size={18}/></div>
                  <div className="flex-1">
                     <input type="text" placeholder="Adapt to Location..." className="w-full bg-transparent text-[11px] font-bold outline-none placeholder:text-nixtio-gray/40" value={selectedGeo} onChange={(e) => setSelectedGeo(e.target.value)} />
                  </div>
                  <button onClick={() => geoAdaptContent(currentItem, selectedGeo, brandInfo).then(up => updatePlanItem(currentItem.day, up))} className="p-2.5 bg-nixtio-black text-white rounded-xl hover:bg-nixtio-purple transition-all"><Rocket size={14}/></button>
               </div>
               <button className="py-5 rounded-3xl bg-nixtio-black text-white text-[11px] font-black uppercase tracking-widest shadow-cta flex items-center justify-center gap-3 hover:scale-[1.01] transition-all"><Rocket size={16} /> Instant Deploy</button>
            </div>
          </div>
        </div>

        {/* Right Column: Activity & Trends */}
        <div className="lg:col-span-3 flex flex-col gap-6 overflow-y-auto custom-scroll pr-2">
          
          {/* Recent Activity Feed */}
          <div className="glass-panel p-6 rounded-[2.5rem] bg-white border border-nixtio-purple/10 shadow-sm">
            <h3 className="text-[10px] font-black text-nixtio-gray uppercase tracking-widest mb-4 flex items-center gap-2">
              <History size={14}/> Recent Activity
            </h3>
            <div className="space-y-4">
              {isLoadingData ? (
                <p className="text-[10px] font-bold text-nixtio-gray animate-pulse">Syncing nodes...</p>
              ) : (
                activities.map(act => (
                  <ActivityItem key={act.id} label={act.label} status={act.status} time={act.time} />
                ))
              )}
            </div>
          </div>

          {/* Trend Scanner Widget */}
          <div className="glass-panel p-6 rounded-[2.5rem] bg-slate-900 text-white shadow-xl">
            <h3 className="text-[10px] font-black text-nixtio-soft uppercase tracking-widest mb-4 flex items-center gap-2">
              <TrendingUp size={14}/> Trending Now
            </h3>
            <div className="space-y-3">
              <TrendWidgetItem title="Audio: Sped-up Funk" tag="Viral Audio" onClick={onUseTemplate} />
              <TrendWidgetItem title="Topic: AI Regulation" tag="Tech News" onClick={onUseTemplate} />
              <TrendWidgetItem title="Hook: 'I tried it so you...'" tag="Growth Hack" onClick={onUseTemplate} />
            </div>
          </div>

          {/* Brand Safety HUD (Condensed) */}
          <div className="glass-panel p-6 rounded-[2.5rem] bg-nixtio-purple/5 border border-nixtio-purple/10">
             <div className="flex items-center gap-2 mb-4">
                <MessageSquareWarning size={14} className="text-nixtio-purple"/>
                <span className="text-[9px] font-black uppercase tracking-widest text-nixtio-gray">Safety HUD</span>
             </div>
             <div className="space-y-3">
                <div className="flex justify-between items-center text-[10px] font-bold text-nixtio-black">
                  <span className="text-nixtio-gray">Copyright Risk</span>
                  <span className="text-emerald-600">Low</span>
                </div>
                <div className="flex justify-between items-center text-[10px] font-bold text-nixtio-black">
                  <span className="text-nixtio-purple">94%</span>
                </div>
             </div>
          </div>

          {/* Training / Tuning Trigger */}
          <div className="glass-panel p-6 rounded-[2.5rem] bg-white border border-nixtio-black/5 shadow-sm">
             <span className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest block mb-4">Teach the AI</span>
             <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handleRecursiveFeedback(true)} className={`p-4 rounded-2xl border-2 flex items-center justify-center flex-col gap-2 transition-all ${currentItem.performance === 'win' ? 'bg-emerald-50 border-emerald-500 text-emerald-600' : 'bg-white border-transparent hover:border-emerald-200'}`}><Trophy size={18}/> <span className="text-[8px] font-black uppercase">Win</span></button>
                <button onClick={() => handleRecursiveFeedback(false)} className={`p-4 rounded-2xl border-2 flex items-center justify-center flex-col gap-2 transition-all ${currentItem.performance === 'flop' ? 'bg-red-50 border-red-500 text-red-600' : 'bg-white border-transparent hover:border-red-200'}`}><Ban size={18}/> <span className="text-[8px] font-black uppercase">Flop</span></button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, trend }: { icon: React.ReactNode, label: string, value: string, trend: string }) => (
  <div className="glass-panel p-6 rounded-[2.5rem] bg-white/60 border-white hover:border-nixtio-purple/20 transition-all group shadow-sm">
    <div className="flex items-center gap-3 mb-4">
      <div className="w-10 h-10 rounded-2xl bg-white border border-nixtio-black/5 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div>
        <p className="text-[9px] font-black text-nixtio-gray uppercase tracking-widest">{label}</p>
        <h4 className="text-xl font-extrabold text-nixtio-black">{value}</h4>
      </div>
    </div>
    <p className="text-[10px] font-bold text-nixtio-gray tracking-tight">{trend}</p>
  </div>
);

// Explicitly type ActivityItem as React.FC to allow 'key' prop when used in map
const ActivityItem: React.FC<{ label: string, status: 'Completed' | 'Processing' | 'Failed', time: string }> = ({ label, status, time }) => (
  <div className="flex items-center justify-between group">
    <div className="flex items-center gap-3">
      <div className={`w-1.5 h-1.5 rounded-full ${status === 'Completed' ? 'bg-emerald-500' : status === 'Processing' ? 'bg-nixtio-purple animate-pulse' : 'bg-red-500'}`}></div>
      <div>
        <p className="text-[10px] font-bold text-nixtio-black leading-none">{label}</p>
        <p className="text-[8px] font-bold text-nixtio-gray mt-1">{time}</p>
      </div>
    </div>
    <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${status === 'Completed' ? 'text-emerald-600 bg-emerald-50' : status === 'Processing' ? 'text-nixtio-purple bg-nixtio-purple/5' : 'text-red-600 bg-red-50'}`}>{status}</span>
  </div>
);

const TrendWidgetItem = ({ title, tag, onClick }: { title: string, tag: string, onClick?: () => void }) => (
  <div className="p-3 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all cursor-pointer group" onClick={onClick}>
    <div className="flex justify-between items-start mb-1">
      <p className="text-[10px] font-bold text-white leading-tight group-hover:text-nixtio-soft transition-colors">{title}</p>
      <button className="text-nixtio-soft hover:text-white transition-colors"><ChevronRight size={14}/></button>
    </div>
    <div className="flex items-center justify-between">
      <span className="text-[8px] font-black text-white/40 uppercase tracking-widest">{tag}</span>
      <button className="text-[8px] font-black text-nixtio-soft uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Use Template</button>
    </div>
  </div>
);

const ForensicMeter = ({ label, value }: { label: string, value: number }) => (
  <div className="text-center">
     <div className="text-[7px] font-black text-white/60 uppercase mb-1">{label}</div>
     <div className="text-[10px] font-black text-white">{value}%</div>
     <div className="h-1 w-full bg-white/10 rounded-full mt-1 overflow-hidden">
        <div className="h-full bg-nixtio-purple rounded-full" style={{ width: `${value}%` }}></div>
     </div>
  </div>
);

export default Dashboard;
