
import React, { createContext, useContext, useEffect, useState, useRef, ReactNode } from 'react';
import { CheckCircle2, Bell, X, Info, AlertTriangle } from 'lucide-react';

interface WebSocketMessage {
  type: 'JOB_COMPLETE' | 'JOB_FAILED' | 'SYSTEM_ALERT';
  payload: any;
}

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
  projectName?: string;
}

interface WebSocketContextType {
  isConnected: boolean;
  sendMessage: (msg: any) => void;
  toasts: Toast[];
  removeToast: (id: string) => void;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

export const WebSocketProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);

  const wsUrl = (import.meta as any).env?.VITE_WS_URL || 'wss://api.contentpilot.ai/ws';

  const addToast = (toast: Omit<Toast, 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const connect = () => {
    try {
      const socket = new WebSocket(wsUrl);
      socketRef.current = socket;

      socket.onopen = () => {
        console.log('Pilot OS: Neural Link Established (WS)');
        setIsConnected(true);
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };

      socket.onmessage = (event) => {
        try {
          const data: WebSocketMessage = JSON.parse(event.data);
          
          if (data.type === 'JOB_COMPLETE') {
            addToast({
              type: 'success',
              message: `Video Ready: ${data.payload.projectName || 'Neural Asset'}`,
              projectName: data.payload.projectName
            });
          } else if (data.type === 'JOB_FAILED') {
            addToast({
              type: 'error',
              message: `Synthesis Failed: ${data.payload.error || 'Unknown Error'}`
            });
          }
        } catch (e) {
          console.error('WS Parse Error', e);
        }
      };

      socket.onclose = () => {
        setIsConnected(false);
        console.log('Pilot OS: Neural Link Severed. Retrying...');
        reconnectTimeoutRef.current = window.setTimeout(connect, 3000);
      };

      socket.onerror = (err) => {
        console.error('WS Error', err);
        socket.close();
      };
    } catch (e) {
      console.error('WS Connection Attempt Failed', e);
    }
  };

  useEffect(() => {
    connect();
    return () => {
      if (socketRef.current) socketRef.current.close();
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
    };
  }, []);

  const sendMessage = (msg: any) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(msg));
    }
  };

  return (
    <WebSocketContext.Provider value={{ isConnected, sendMessage, toasts, removeToast }}>
      {children}
      
      {/* Global Toast Overlay */}
      <div className="fixed top-6 right-6 z-[300] flex flex-col gap-3 pointer-events-none">
        {toasts.map((toast) => (
          <div 
            key={toast.id} 
            className={`pointer-events-auto flex items-center gap-4 p-5 rounded-3xl shadow-2xl border backdrop-blur-xl animate-fade-in min-w-[320px] ${
              toast.type === 'success' ? 'bg-emerald-500/90 border-emerald-400 text-white' : 
              toast.type === 'error' ? 'bg-red-500/90 border-red-400 text-white' : 
              'bg-nixtio-black/90 border-white/10 text-white'
            }`}
          >
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              {toast.type === 'success' && <CheckCircle2 size={20} />}
              {toast.type === 'error' && <AlertTriangle size={20} />}
              {toast.type === 'info' && <Bell size={20} />}
            </div>
            <div className="flex-1">
              <p className="text-[11px] font-black uppercase tracking-widest leading-none mb-1 opacity-60">
                {toast.type === 'success' ? 'Synthesis Complete' : toast.type === 'error' ? 'System Alert' : 'Notification'}
              </p>
              <p className="text-xs font-bold leading-tight">{toast.message}</p>
            </div>
            <button 
              onClick={() => removeToast(toast.id)}
              className="p-2 hover:bg-white/10 rounded-xl transition-all"
            >
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </WebSocketContext.Provider>
  );
};

export const useWebSocket = () => {
  const context = useContext(WebSocketContext);
  if (context === undefined) {
    throw new Error('useWebSocket must be used within a WebSocketProvider');
  }
  return context;
};
